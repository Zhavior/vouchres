export interface DetectedLeg {
  id: string;
  rawText: string;
  sport: string;
  league: string;
  sportsbook: string;
  playerName: string | null;
  team: string | null;
  opponent: string | null;
  gameText: string | null;
  market: string;
  normalizedMarket: string;
  line: string | null;
  odds: string;
  isSameGameParlay: boolean;
  confidence: number;
  needsReview: boolean;
  warnings: string[];
}

export interface ScanResult {
  scanId: string;
  sportsbook: string;
  ticketType: string; // e.g., 'Parlay', 'Straight', 'Teaser', 'Round Robin'
  totalLegs: number;
  detectedLegs: DetectedLeg[];
  overallConfidence: number;
  needsUserReview: boolean;
  warnings: string[];
  rawTextSummary: string;
  createdAt: string;
}
