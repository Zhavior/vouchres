import { DetectedLeg } from "./ticketExtractionSchema";

/**
 * Ensures no mock or hardcoded player fallbacks are slipped into the production results 
 * unless they are explicitly present in the raw OCR text extracted from the screenshot.
 */
export function enforceMockDataGuard(
  legs: DetectedLeg[],
  rawOcrText: string,
  allowMocks: boolean
): { filteredLegs: DetectedLeg[]; warnings: string[] } {
  const warnings: string[] = [];
  const textLower = (rawOcrText || "").toLowerCase();

  // If mock data is explicitly forbidden, we filter out legs that don't match the image text
  const filteredLegs = legs.filter(leg => {
    // If we aren't allowing mocks/hallucinations, do a validation
    if (!allowMocks) {
      if (leg.playerName && leg.playerName !== "None") {
        const nameParts = leg.playerName.toLowerCase().split(/\s+/);
        // Ensure at least one distinct part of the name is present in the raw extracted text
        const matched = nameParts.some(part => part.length > 2 && textLower.includes(part));
        if (!matched) {
          warnings.push(`Filtered out potential hallucinated player: "${leg.playerName}" (not found in raw text).`);
          return false;
        }
      }
    }
    return true;
  });

  return {
    filteredLegs,
    warnings
  };
}
