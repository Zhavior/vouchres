import { DetectedLeg } from "./ticketExtractionSchema";

/**
 * Calculates a rigorous confidence score from 0.0 to 1.0 for an extracted ticket leg.
 */
export function scoreLegConfidence(leg: Partial<DetectedLeg>): { confidence: number; needsReview: boolean; warnings: string[] } {
  const warnings: string[] = [];
  let score = 1.0;

  // 1. Missing structural information checks
  if (!leg.sport || leg.sport === "Unknown") {
    score -= 0.2;
    warnings.push("Sport is unidentified.");
  }

  const isPlayerProp = ["player_home_run", "pitcher_strikeouts", "player_rbi", "player_hits", "player_total_bases"].includes(leg.normalizedMarket || "");
  if (isPlayerProp) {
    if (!leg.playerName || leg.playerName === "None" || leg.playerName === "null") {
      score -= 0.35;
      warnings.push("Player-prop market detected, but athlete name is missing.");
    }
  } else {
    if (!leg.team || leg.team === "None" || leg.team === "null") {
      score -= 0.25;
      warnings.push("Team-prop market detected, but betting team is missing.");
    }
  }

  // 2. Validate odds format (e.g., +390, -110, 1.91)
  const cleanOdds = (leg.odds || "").trim();
  const oddsRegex = /^([+-]\d{3,4}|\d+\.\d+)$/;
  if (!cleanOdds || cleanOdds === "None") {
    score -= 0.3;
    warnings.push("Betting odds are missing or unreadable.");
  } else if (!oddsRegex.test(cleanOdds)) {
    score -= 0.15;
    warnings.push(`Non-standard odds format detected: "${cleanOdds}".`);
  }

  // 3. Validation against raw source matching
  const rawTextLower = (leg.rawText || "").toLowerCase();
  if (leg.playerName && leg.playerName !== "None") {
    const nameParts = leg.playerName.toLowerCase().split(/\s+/);
    const hasMatch = nameParts.some(part => part.length > 2 && rawTextLower.includes(part));
    if (!hasMatch) {
      score -= 0.4;
      warnings.push(`Extracted player "${leg.playerName}" was not confidently found in raw screenshot text segment.`);
    }
  }

  // 4. Extreme noise/length penalty
  if ((leg.rawText || "").length > 250) {
    score -= 0.1;
    warnings.push("Excessive noise or long segment text read for this leg.");
  }

  // Ensure bounded score [0.0, 1.0]
  const finalConfidence = Math.max(0.0, Math.min(1.0, parseFloat(score.toFixed(2))));
  const needsReview = finalConfidence < 0.8;

  if (needsReview && warnings.length === 0) {
    warnings.push("Low parsing confidence score. Needs manual audit.");
  }

  return {
    confidence: finalConfidence,
    needsReview,
    warnings
  };
}
