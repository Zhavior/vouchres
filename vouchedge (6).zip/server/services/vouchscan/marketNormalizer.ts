/**
 * Normalizes raw sportsbook market text into clean, standard, machine-readable keys.
 */
export function normalizeMarket(rawMarket: string): { normalized: string; displayName: string } {
  const clean = (rawMarket || "").toLowerCase().trim();

  // 1. Home Run Markets
  if (
    clean.includes("home run") || 
    clean.includes("to hit a home run") || 
    clean.includes("hr") || 
    clean.includes("homerun")
  ) {
    return { normalized: "player_home_run", displayName: "To Hit A Home Run" };
  }

  // 2. Strikeout Markets
  if (
    clean.includes("strikeout") || 
    clean.includes("pitcher strikeouts") || 
    clean.includes("so") || 
    clean.includes("k's")
  ) {
    return { normalized: "pitcher_strikeouts", displayName: "Pitcher Strikeouts" };
  }

  // 3. Runs Batted In (RBI)
  if (clean.includes("rbi") || clean.includes("runs batted in")) {
    return { normalized: "player_rbi", displayName: "Player RBI" };
  }

  // 4. Hits
  if (clean.includes("hits") || clean.includes("player hits")) {
    return { normalized: "player_hits", displayName: "Player Hits" };
  }

  // 5. Total Bases
  if (clean.includes("total bases") || clean.includes("tb")) {
    return { normalized: "player_total_bases", displayName: "Player Total Bases" };
  }

  // 6. Moneyline
  if (clean.includes("moneyline") || clean.includes("money line") || clean.includes("ml")) {
    return { normalized: "team_moneyline", displayName: "Moneyline" };
  }

  // 7. Spread / Run Line / Point Spread
  if (
    clean.includes("spread") || 
    clean.includes("run line") || 
    clean.includes("runline") || 
    clean.includes("point spread")
  ) {
    return { normalized: "team_spread", displayName: "Spread / Run Line" };
  }

  // 8. Total Runs / Game Totals / Over Under
  if (
    clean.includes("total runs") || 
    clean.includes("game total") || 
    clean.includes("over/under") || 
    clean.includes("total points")
  ) {
    return { normalized: "game_total", displayName: "Total Runs" };
  }

  // Fallback to title-cased raw value
  const displayName = rawMarket
    ? rawMarket.charAt(0).toUpperCase() + rawMarket.slice(1)
    : "Unknown Market";
    
  return {
    normalized: clean.replace(/\s+/g, "_"),
    displayName
  };
}
