import { DetectedLeg } from "./ticketExtractionSchema";

export interface ValidationReport {
  isValid: boolean;
  validatedLegs: DetectedLeg[];
  errors: string[];
  warnings: string[];
}

/**
 * Validates the structured output from the vision API.
 * Ensures strict support by rawText and filters out unverified hallucinated legs.
 */
export function validateTicket(
  rawLegs: any[],
  rawOcrText: string
): ValidationReport {
  const errors: string[] = [];
  const warnings: string[] = [];
  const validatedLegs: DetectedLeg[] = [];
  
  const textLower = (rawOcrText || "").toLowerCase();

  if (!Array.isArray(rawLegs)) {
    return {
      isValid: false,
      validatedLegs: [],
      errors: ["Extracted legs is not a valid array."],
      warnings: []
    };
  }

  for (let i = 0; i < rawLegs.length; i++) {
    const rawLeg = rawLegs[i];
    const legId = rawLeg.id || `leg-val-${Date.now()}-${i}`;
    
    // Check that there is at least some raw text indicating this selection exists
    const legRawText = (rawLeg.rawText || "").trim();
    if (!legRawText) {
      warnings.push(`Leg #${i + 1} skipped: missing 'rawText' supporting field.`);
      continue;
    }

    // Verify rawText matches the image text bounds reasonably
    const legRawTextLower = legRawText.toLowerCase();
    const isSupportedByOcr = textLower.includes(legRawTextLower) || 
                             legRawTextLower.split(/\s+/).filter(w => w.length > 2).some(word => textLower.includes(word));

    if (!isSupportedByOcr) {
      warnings.push(`Rejected leg for player "${rawLeg.playerName || "Unknown"}": not supported by OCR rawText.`);
      continue;
    }

    // Build fully typed and validated DetectedLeg item
    const validatedLeg: DetectedLeg = {
      id: legId,
      rawText: legRawText,
      sport: rawLeg.sport || "MLB",
      league: rawLeg.league || "MLB",
      sportsbook: rawLeg.sportsbook || "Unknown",
      playerName: rawLeg.playerName && rawLeg.playerName !== "None" ? rawLeg.playerName : null,
      team: rawLeg.team && rawLeg.team !== "None" ? rawLeg.team : null,
      opponent: rawLeg.opponent && rawLeg.opponent !== "None" ? rawLeg.opponent : null,
      gameText: rawLeg.gameText || null,
      market: rawLeg.market || "Unknown Market",
      normalizedMarket: rawLeg.normalizedMarket || "unknown",
      line: rawLeg.line && rawLeg.line !== "None" ? rawLeg.line : null,
      odds: rawLeg.odds || "+100",
      isSameGameParlay: !!rawLeg.isSameGameParlay,
      confidence: typeof rawLeg.confidence === "number" ? rawLeg.confidence : 0.8,
      needsReview: !!rawLeg.needsReview,
      warnings: Array.isArray(rawLeg.warnings) ? rawLeg.warnings : []
    };

    validatedLegs.push(validatedLeg);
  }

  return {
    isValid: validatedLegs.length > 0,
    validatedLegs,
    errors,
    warnings
  };
}
