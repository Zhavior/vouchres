import { GoogleGenAI, Type } from "@google/genai";
import { preprocessImage } from "./imagePreprocessService";

export interface VisionExtractedRaw {
  rawOcrText: string;
  detectedSportsbook: string;
  ticketType: string;
  legs: Array<{
    sport: string;
    league: string;
    sportsbook: string;
    playerName: string;
    team: string;
    opponent: string;
    gameText: string;
    market: string;
    line: string;
    odds: string;
    isSameGameParlay: boolean;
    rawText: string;
  }>;
}

/**
 * Executes OCR and structured layout extraction on the parlay image using Gemini Vision AI.
 * Optionally falls back to OpenAI Vision if configured and GEMINI fails or is not available.
 */
export async function extractTicketWithVision(
  imageBase64: string,
  filename: string,
  provider: "gemini" | "openai" = "gemini"
): Promise<{ rawOcrText: string; legs: any[]; detectedSportsbook: string; ticketType: string; providerUsed: string }> {
  
  const { cleanBase64, mimeType } = preprocessImage(imageBase64);
  const geminiKey = process.env.GEMINI_API_KEY;
  const openaiKey = process.env.OPENAI_API_KEY;

  const activeProvider = provider === "gemini" && geminiKey ? "gemini" : (openaiKey ? "openai" : "gemini");

  if (activeProvider === "gemini") {
    if (!geminiKey) {
      throw new Error("GEMINI_API_KEY is not defined in the environment secrets.");
    }

    const ai = new GoogleGenAI({
      apiKey: geminiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        }
      }
    });

    // Detailed prompt instructing Gemini on strict sport ticket layout reading rules
    const prompt = `You are a sports betting ticket parser. Read the parlay screenshot carefully.
Extract each leg, team names, athletes, betting markets, lines, and odds.
STRICT RULES FOR EXTRACTION:
- Extract ONLY information visible in the uploaded image.
- Do NOT guess, invent, or hallucinate names, lines, or odds.
- Do NOT use standard or default placeholder players (e.g., Shohei Ohtani, Paul Skenes, Aaron Judge) unless they are physically printed and visible in this exact screenshot.
- Extract the exact text line that supports each leg into "rawText".
- Group player, team, market, and odds visually belonging to the same leg together.
- For player home run props, the playerName must be the exact athlete's name, e.g. "Joc Pederson" or "Colson Montgomery".
- Extract exact odds such as +390, +310, -110.

Return the result as structured JSON matching the requested schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [
        {
          inlineData: {
            mimeType: mimeType || "image/png",
            data: cleanBase64,
          }
        },
        { text: prompt }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            rawOcrText: { 
              type: Type.STRING, 
              description: "The complete raw OCR text reconstruction of the ticket" 
            },
            detectedSportsbook: { 
              type: Type.STRING, 
              description: "Sportsbook name, e.g., 'Bet365', 'FanDuel', 'DraftKings', 'Bovada', or 'Unknown'" 
            },
            ticketType: { 
              type: Type.STRING, 
              description: "E.g., 'Parlay', 'Straight', 'Same Game Parlay'" 
            },
            legs: {
              type: Type.ARRAY,
              description: "Array of parlay legs",
              items: {
                type: Type.OBJECT,
                properties: {
                  sport: { type: Type.STRING, description: "Sport name, e.g., 'MLB', 'NBA', 'NFL'" },
                  league: { type: Type.STRING, description: "League name, e.g., 'MLB', 'NBA'" },
                  sportsbook: { type: Type.STRING },
                  playerName: { type: Type.STRING, description: "Athlete's name, or 'None' if not a player prop" },
                  team: { type: Type.STRING, description: "Betting team name or 'None'" },
                  opponent: { type: Type.STRING, description: "Opponent team name or 'None'" },
                  gameText: { type: Type.STRING, description: "Matchup text description, e.g., 'ARI Diamondbacks @ MIA Marlins'" },
                  market: { type: Type.STRING, description: "Exact market name, e.g., 'To Hit A Home Run', 'Player Strikeouts'" },
                  line: { type: Type.STRING, description: "E.g. 'Over 0.5', 'Over 7.5', or 'None'" },
                  odds: { type: Type.STRING, description: "E.g. '+390', '-110', '2.00'" },
                  isSameGameParlay: { type: Type.BOOLEAN },
                  rawText: { type: Type.STRING, description: "Exact OCR text snippet supporting this leg" }
                },
                required: ["sport", "market", "odds", "rawText"]
              }
            }
          },
          required: ["rawOcrText", "detectedSportsbook", "legs"]
        }
      }
    });

    const text = response.text || "";
    const parsed = JSON.parse(text.trim()) as VisionExtractedRaw;
    
    return {
      rawOcrText: parsed.rawOcrText,
      legs: parsed.legs || [],
      detectedSportsbook: parsed.detectedSportsbook || "Unknown",
      ticketType: parsed.ticketType || "Parlay",
      providerUsed: "gemini"
    };
  } else if (activeProvider === "openai") {
    // Optional OpenAI Vision fallback
    if (!openaiKey) {
      throw new Error("OPENAI_API_KEY is not defined in the environment secrets.");
    }

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${openaiKey}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        response_format: { type: "json_object" },
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Extract sports betting ticket info in JSON format.
                      Schema:
                      {
                        "rawOcrText": "reconstructed text",
                        "detectedSportsbook": "sportsbook name",
                        "ticketType": "Parlay/Straight",
                        "legs": [
                          {
                            "sport": "MLB",
                            "league": "MLB",
                            "sportsbook": "Bet365",
                            "playerName": "Joc Pederson",
                            "team": "ARI Diamondbacks",
                            "opponent": "MIA Marlins",
                            "gameText": "Texas Rangers @ Miami Marlins",
                            "market": "To Hit A Home Run",
                            "line": "Over 0.5",
                            "odds": "+390",
                            "isSameGameParlay": false,
                            "rawText": "Joc Pederson To Hit a Home Run +390"
                          }
                        ]
                      }`
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:${mimeType};base64,${cleanBase64}`
                }
              }
            ]
          }
        ]
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API request failed: ${response.statusText}`);
    }

    const data = await response.json();
    const textContent = data.choices[0].message.content || "";
    const parsed = JSON.parse(textContent.trim()) as VisionExtractedRaw;

    return {
      rawOcrText: parsed.rawOcrText,
      legs: parsed.legs || [],
      detectedSportsbook: parsed.detectedSportsbook || "Unknown",
      ticketType: parsed.ticketType || "Parlay",
      providerUsed: "openai"
    };
  }

  throw new Error("No primary vision model provider is configured or available.");
}
