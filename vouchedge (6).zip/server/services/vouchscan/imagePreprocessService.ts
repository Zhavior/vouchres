import { Buffer } from "buffer";

export interface PreprocessedImage {
  cleanBase64: string;
  mimeType: string;
  sizeBytes: number;
  width?: number;
  height?: number;
  warnings: string[];
}

/**
 * Validates and prepares the uploaded base64 screenshot for vision extraction.
 */
export function preprocessImage(imageBase64: string): PreprocessedImage {
  const warnings: string[] = [];
  
  if (!imageBase64) {
    throw new Error("No image data provided for preprocessing.");
  }

  // Detect mime type or default to image/png
  let mimeType = "image/png";
  const mimeMatch = imageBase64.match(/^data:(image\/\w+);base64,/);
  if (mimeMatch) {
    mimeType = mimeMatch[1];
  } else {
    warnings.push("Missing data URI prefix. Defaulting format to image/png.");
  }

  // Extract raw base64 data without prefixes
  const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");
  
  // Calculate size in bytes
  let sizeBytes = 0;
  try {
    const buffer = Buffer.from(cleanBase64, "base64");
    sizeBytes = buffer.length;
    
    // Check for standard size constraints
    if (sizeBytes < 5000) {
      warnings.push("Image size is extremely small. The screenshot may be low resolution or corrupted.");
    } else if (sizeBytes > 10 * 1024 * 1024) {
      warnings.push("Image is very large. Processing might be slow or hit token payload limits.");
    }
  } catch (err: any) {
    throw new Error(`Failed to decode base64 string: ${err.message}`);
  }

  return {
    cleanBase64,
    mimeType,
    sizeBytes,
    warnings
  };
}
