export interface DetectedLeg {
  id: string;
  sport: string;
  league: string;
  playerName: string;
  team: string;
  opponent: string;
  market: string;
  line: string;
  odds: string;
  sportsbookName: string;
  detectionConfidence: number;
  rawText: string;
  needsReview: boolean;
}

export interface JudgeOutput {
  finalScore: number;
  approvalStatus: 'Tail' | 'Wait' | 'Fade' | 'Lotto Only' | 'Needs More Data';
  riskLabel: string;
  judgeNotes: string;
  whatCouldGoWrong: string;
  missingData: string;
  parlayAllowed: boolean;
}

export interface AgentReview {
  agentId: string;
  agentName: string;
  role: string;
  confidence: number;
  verdict: 'Support' | 'Caution' | 'Oppose' | 'Neutral';
  notes: string;
  riskFactor: string;
}

export interface VouchCheckReport {
  id: string;
  parlayHash: string;
  createdAt: string;
  legs: DetectedLeg[];
  overallVouchScore: number;
  verdict: 'Tail' | 'Wait' | 'Fade' | 'Lotto Only' | 'Needs More Data';
  judgeVerdict: JudgeOutput;
  agentReviews: AgentReview[];
  playerStats: {
    playerName: string;
    avg: string;
    hr: string;
    rbi: string;
    ops: string;
    recentTrend: string;
    matchupNotes: string;
  }[];
  pitcherVulnerability: {
    pitcherName: string;
    team: string;
    era: string;
    whip: string;
    strikeoutRate: string;
    vulnerabilityScore: number; // 0-100
    vulnerabilityNotes: string;
    allowedStat: string;
  }[];
  weatherParkImpact: {
    game: string;
    temperature: string;
    wind: string;
    elevation: string;
    parkFactor: string;
    impactScore: number; // -10 to +10
    impactNotes: string;
  }[];
  correlationRisk: {
    riskLevel: 'None' | 'Low' | 'Medium' | 'High';
    description: string;
    isNegativeCorrelation: boolean;
  };
  whatCouldGoWrong: string[];
  saferAlternative: {
    description: string;
    originalOdds: string;
    saferOdds: string;
    legs: {
      originalSelection: string;
      saferSelection: string;
      reason: string;
    }[];
  };
  shareToken: string;
}
