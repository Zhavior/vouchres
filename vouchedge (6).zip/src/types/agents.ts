export interface AgentConfig {
  id: string;
  name: string;
  role: string;
  personality: string;
  riskTolerance: 'Low' | 'Medium' | 'High' | 'Extremely High';
  preferredMarkets: string[];
  researchStyle: string;
  strengths: string[];
  weakness: string;
  biasRisk: string;
  tone: string;
  enabled: boolean;
  runMode: 'deterministic' | 'ai_optional' | 'full_ai';
}

export interface AgentRunResult {
  agentId: string;
  agentName: string;
  role: string;
  pick: {
    gameId: string;
    team: string;
    market: string;
    odds: string;
    units: number;
    explanation: string;
  } | null;
  report: string | null;
  confidence: number;
  riskLabel: 'Safe' | 'Balanced' | 'Risky' | 'Sneaky' | 'Lotto';
  judgeStatus: 'Approved' | 'Playable but risky' | 'Needs more data' | 'Avoid';
  explanation: string;
  whatCouldGoWrong: string;
  missingData: string[];
  dataQuality: 'excellent' | 'good' | 'limited' | 'unreliable';
}
