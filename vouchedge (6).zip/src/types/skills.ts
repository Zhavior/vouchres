export interface SkillConfig {
  id: string;
  name: string;
  description: string;
  category: 'data_fetching' | 'mlb_analytics' | 'parlay_building' | 'grading_trust' | 'profile_rewards';
  inputSchema: Record<string, string>;
  outputSchema: Record<string, string>;
  enabled: boolean;
}
