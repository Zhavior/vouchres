import React, { createContext, useContext, useState, useEffect } from 'react';
import { CreatorProofProfile } from '../../types';
import { THEME_REGISTRY, BORDER_REGISTRY, VisualTheme, ProfileBorder } from '../../theme/themeRegistry';

interface ThemeContextType {
  currentAppTheme: VisualTheme;
  currentProfileTheme: VisualTheme;
  currentBorder: ProfileBorder | null;
  activeTheme: VisualTheme; // Automatically falls back to override if view is active
  overrideTheme: VisualTheme | null;
  setAppTheme: (themeId: string) => void;
  setProfileTheme: (themeId: string) => void;
  setBorder: (borderId: string | null) => void;
  setOverrideTheme: (themeId: string | null) => void;
  unlockedThemes: string[];
  unlockedBorders: string[];
  unlockTheme: (themeId: string) => void;
  unlockBorder: (borderId: string) => void;
  reduceMotion: boolean;
  setReduceMotion: (val: boolean) => void;
  userCredits: number;
  setUserCredits: (val: number) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

interface ThemeProviderProps {
  profile: CreatorProofProfile;
  onUpdateProfile: (updates: Partial<CreatorProofProfile>) => void;
  children: React.ReactNode;
}

export function ThemeProvider({ profile, onUpdateProfile, children }: ThemeProviderProps) {
  const [overrideThemeId, setOverrideThemeId] = useState<string | null>(null);
  
  // Manage user credits in localStorage
  const [userCredits, setUserCreditsState] = useState<number>(() => {
    const cached = localStorage.getItem('vouchedge_theme_credits');
    if (cached) return parseInt(cached, 10);
    localStorage.setItem('vouchedge_theme_credits', '1000');
    return 1000;
  });

  const setUserCredits = (val: number) => {
    setUserCreditsState(val);
    localStorage.setItem('vouchedge_theme_credits', val.toString());
  };

  // Sync unlocked lists with legacy fields to prevent any data loss
  const unlockedThemes = profile.unlockedThemeIds || profile.boughtThemes || ['cyber-blue', '4bit-arcade', 'proof-mode'];
  const unlockedBorders = profile.unlockedBorderIds || ['default-cyber-ring'];

  // Resolve Themes
  const currentAppTheme = THEME_REGISTRY.find(t => t.id === (profile.appThemeId || profile.activeTheme)) || THEME_REGISTRY[0];
  const currentProfileTheme = THEME_REGISTRY.find(t => t.id === profile.profileThemeId) || currentAppTheme;
  const currentBorder = BORDER_REGISTRY.find(b => b.id === profile.profileBorderId) || BORDER_REGISTRY[0];

  // Resolve Active Theme
  const overrideTheme = overrideThemeId ? (THEME_REGISTRY.find(t => t.id === overrideThemeId) || null) : null;
  const activeTheme = overrideTheme || currentAppTheme;

  const setAppTheme = (themeId: string) => {
    onUpdateProfile({ 
      appThemeId: themeId,
      activeTheme: themeId // Maintain backward compatibility
    });
  };

  const setProfileTheme = (themeId: string) => {
    onUpdateProfile({ profileThemeId: themeId });
  };

  const setBorder = (borderId: string | null) => {
    onUpdateProfile({ profileBorderId: borderId || undefined });
  };

  const setOverrideTheme = (themeId: string | null) => {
    setOverrideThemeId(themeId);
  };

  const unlockTheme = (themeId: string) => {
    if (!unlockedThemes.includes(themeId)) {
      const nextThemes = [...unlockedThemes, themeId];
      onUpdateProfile({ 
        unlockedThemeIds: nextThemes,
        boughtThemes: nextThemes // Keep synced for backward compatibility
      });
    }
  };

  const unlockBorder = (borderId: string) => {
    if (!unlockedBorders.includes(borderId)) {
      onUpdateProfile({ unlockedBorderIds: [...unlockedBorders, borderId] });
    }
  };

  const reduceMotion = !!profile.reduceMotion;
  const setReduceMotion = (val: boolean) => {
    onUpdateProfile({ reduceMotion: val });
  };

  // Add styles to document based on active theme
  useEffect(() => {
    const root = document.documentElement;
    // Set fontFamily
    if (activeTheme.fontFamily === 'font-mono') {
      root.style.fontFamily = '"JetBrains Mono", ui-monospace, SFMono-Regular, monospace';
    } else {
      root.style.fontFamily = '"Inter", ui-sans-serif, system-ui, sans-serif';
    }

    // Set custom CSS variables for any sub-components that reference theme vars
    root.style.setProperty('--theme-accent-color', activeTheme.accentText.includes('cyan') ? '#22d3ee' : activeTheme.accentText.includes('orange') ? '#f97316' : activeTheme.accentText.includes('emerald') ? '#10b981' : activeTheme.accentText.includes('rose') ? '#e11d48' : '#eab308');
    root.style.setProperty('--theme-border-color', activeTheme.borderColor || 'rgba(6,182,212,0.2)');
    root.style.setProperty('--theme-glow-color', activeTheme.accentText.includes('cyan') ? 'rgba(6,182,212,0.3)' : activeTheme.accentText.includes('orange') ? 'rgba(249,115,22,0.3)' : activeTheme.accentText.includes('emerald') ? 'rgba(16,185,129,0.3)' : activeTheme.accentText.includes('rose') ? 'rgba(225,29,72,0.3)' : 'rgba(234,179,8,0.3)');
  }, [activeTheme]);

  return (
    <ThemeContext.Provider value={{
      currentAppTheme,
      currentProfileTheme,
      currentBorder,
      activeTheme,
      overrideTheme,
      setAppTheme,
      setProfileTheme,
      setBorder,
      setOverrideTheme,
      unlockedThemes,
      unlockedBorders,
      unlockTheme,
      unlockBorder,
      reduceMotion,
      setReduceMotion,
      userCredits,
      setUserCredits
    }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
