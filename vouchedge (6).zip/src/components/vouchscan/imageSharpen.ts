/**
 * Premium Image Processing Utilities for VouchScan
 * Applies a 3x3 high-contrast convolution matrix to sharpen individual letter bounds and digit outlines on parlay slips.
 */

export function sharpenImage(base64Str: string, strength: 'medium' | 'high' = 'high'): Promise<string> {
  return new Promise((resolve) => {
    // If it's a tiny mock placeholder, don't try to canvas-process it
    if (!base64Str.startsWith('data:image/') || base64Str.length < 500) {
      resolve(base64Str);
      return;
    }

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = base64Str;
    
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(base64Str);
          return;
        }

        // Preserve 100% original size and native resolution of the uploaded parlay ticket image.
        // No down-scaling or quality compression is applied to prevent any loss of digit or letter readability on high-res screenshots.
        const w = img.width;
        const h = img.height;

        canvas.width = w;
        canvas.height = h;

        // Draw original image
        ctx.drawImage(img, 0, 0, w, h);

        const imageData = ctx.getImageData(0, 0, w, h);
        const data = imageData.data;
        const outputData = ctx.createImageData(w, h);
        const output = outputData.data;

        // Sharpen kernel definition
        // Medium: standard high-frequency pass
        // High: strong laplacian style edge contrast boost
        const kernel = strength === 'high'
          ? [
              -1, -1, -1,
              -1,  9, -1,
              -1, -1, -1
            ]
          : [
               0, -1,  0,
              -1,  5, -1,
               0, -1,  0
            ];

        const side = 3;
        const halfSide = 1;

        // Pre-fill the alpha channel to preserve full opacity
        for (let i = 0; i < data.length; i += 4) {
          output[i + 3] = data[i + 3];
        }

        // Apply convolution filter across all color channels
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const dstOff = (y * w + x) * 4;

            let r = 0;
            let g = 0;
            let b = 0;

            for (let cy = 0; cy < side; cy++) {
              for (let cx = 0; cx < side; cx++) {
                const scy = Math.min(h - 1, Math.max(0, y + cy - halfSide));
                const scx = Math.min(w - 1, Math.max(0, x + cx - halfSide));
                const srcOff = (scy * w + scx) * 4;
                const wt = kernel[cy * side + cx];

                r += data[srcOff] * wt;
                g += data[srcOff + 1] * wt;
                b += data[srcOff + 2] * wt;
              }
            }

            // Clamp results to 0-255 boundaries
            output[dstOff] = Math.min(255, Math.max(0, r));
            output[dstOff + 1] = Math.min(255, Math.max(0, g));
            output[dstOff + 2] = Math.min(255, Math.max(0, b));
          }
        }

        ctx.putImageData(outputData, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      } catch (err) {
        console.warn("Client side image sharpening failed, falling back to original image:", err);
        resolve(base64Str);
      }
    };

    img.onerror = () => {
      resolve(base64Str);
    };
  });
}
