import React, { useState, useRef } from 'react';
import { Upload, Image as ImageIcon, Sparkles } from 'lucide-react';

interface VouchScanDropzoneProps {
  onImageSelected: (base64: string, filename: string) => void;
}

export default function VouchScanDropzone({ onImageSelected }: VouchScanDropzoneProps) {
  const [isDragActive, setIsDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true);
    } else if (e.type === "dragleave") {
      setIsDragActive(false);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('⚠️ Please select a valid image file (PNG, JPG, WEBP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onImageSelected(reader.result, file.name);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  return (
    <div 
      className="w-full max-w-2xl mx-auto"
      id="vouchscan-dropzone-container"
    >
      <div
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative cursor-pointer group rounded-2xl border-2 border-dashed p-8 md:p-12 text-center transition-all duration-300 ${
          isDragActive 
            ? 'border-cyan-400 bg-cyan-950/20 shadow-[0_0_30px_rgba(34,211,238,0.2)]' 
            : 'border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-900/30 hover:shadow-[0_0_20px_rgba(99,102,241,0.1)]'
        }`}
        id="dropzone-interactive-stage"
      >
        {/* Hidden Input */}
        <input 
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleChange}
          className="hidden"
          id="screenshot-file-picker"
        />

        {/* Ambient background glow elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-cyan-500/5 opacity-50 rounded-2xl pointer-events-none" />

        {/* Dynamic content */}
        <div className="relative z-10 flex flex-col items-center justify-center space-y-4">
          <div className={`p-4 rounded-full border transition-transform duration-300 group-hover:scale-110 ${
            isDragActive 
              ? 'bg-cyan-950/60 border-cyan-400 text-cyan-400' 
              : 'bg-slate-900 border-slate-800 text-indigo-400 group-hover:text-cyan-400'
          }`}>
            <Upload className="w-8 h-8 animate-pulse" />
          </div>

          <div className="space-y-1.5 max-w-md mx-auto">
            <h3 className="text-base md:text-lg font-bold text-slate-100 tracking-tight flex items-center justify-center gap-1.5">
              <span>UPLOAD PARLAY SCREENSHOT</span>
              <Sparkles className="w-4 h-4 text-amber-400 fill-amber-400 animate-bounce" />
            </h3>
            <p className="text-xs md:text-sm text-slate-400 font-medium">
              Drag & drop your slip screenshot here, or click to browse files.
            </p>
          </div>

          <div className="pt-4 flex flex-wrap gap-2 items-center justify-center text-[10px] font-mono text-slate-500">
            <span className="px-2.5 py-1 bg-slate-900 border border-slate-850 rounded-full flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              VISION AI OCR EXTRACT
            </span>
            <span className="px-2.5 py-1 bg-slate-900 border border-slate-850 rounded-full">
              PNG, JPG, WEBP
            </span>
            <span className="px-2.5 py-1 bg-slate-900 border border-slate-850 rounded-full">
              MAX 10MB
            </span>
          </div>

          {/* Quick Upload Helper Ideas */}
          <div className="pt-6 border-t border-slate-900/60 w-full max-w-sm mt-4 text-[11px] text-slate-500 leading-relaxed font-semibold">
            Upload slips from DraftKings, FanDuel, Bovada, Underdog, etc. VouchScan will auto-extract every player and prop selection in seconds.
          </div>
        </div>
      </div>
    </div>
  );
}
