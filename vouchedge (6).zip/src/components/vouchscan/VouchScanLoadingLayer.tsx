import React, { useState, useEffect, useRef } from 'react';
import { Loader2, CheckCircle2, Shield, Scan, Cpu, Database, CloudRain, Users, BarChart3, AlertCircle, Play } from 'lucide-react';
import { DetectedLeg } from '../../types/vouchscan';

interface VouchScanLoadingLayerProps {
  onLoadingComplete?: () => void;
  isAnalyzing?: boolean;
  detectedLegs?: DetectedLeg[];
}

export default function VouchScanLoadingLayer({ 
  onLoadingComplete, 
  isAnalyzing = true,
  detectedLegs = []
}: VouchScanLoadingLayerProps) {
  const STAGES = [
    {
      title: "Reading image",
      sub: "Scanning uploaded file bytes, detecting resolution and color contrast ranges.",
      icon: Scan,
      duration: 1000
    },
    {
      title: "Extracting text",
      sub: "Running optical character recognition (OCR) parsing across high-density text bands.",
      icon: Cpu,
      duration: 1000
    },
    {
      title: "Detecting sportsbook",
      sub: "Matching identified text headers and logo placements against known sportsbook layout definitions.",
      icon: Database,
      duration: 1000
    },
    {
      title: "Splitting parlay legs",
      sub: "Identifying and segmenting parlay leg boundary markers and individual prop sections.",
      icon: Shield,
      duration: 1000
    },
    {
      title: "Matching players",
      sub: "Cross-referencing athlete names, matchups, and team profiles against active MLB roster datasets.",
      icon: Users,
      duration: 1000
    },
    {
      title: "Checking confidence",
      sub: "Verifying parse accuracy scoring, raw textual coverage, and bounding-box reliability indicators.",
      icon: BarChart3,
      duration: 1000
    },
    {
      title: "Ready for review",
      sub: "Extraction pipeline complete. Synchronizing parsed fields for user verification and manual correction.",
      icon: CheckCircle2,
      duration: 800
    }
  ];

  const [currentStageIndex, setCurrentStageIndex] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const consoleEndRef = useRef<HTMLDivElement | null>(null);

  // Dynamic log generator based on current stage and detected legs
  useEffect(() => {
    if (currentStageIndex === 0) {
      const providerUsed = detectedLegs[0]?.sportsbookName || "Bet365 / DraftKings Standard";
      setLogs([
        `[INFO] VouchScan Core Engine v4.2 Initialize...`,
        `[DETECTOR] Scanning uploaded screenshot dimensions...`,
        `[DETECTOR] Matching layout markers against known bookmakers: Bet365, DraftKings, FanDuel, Vouch...`,
        `[DETECTOR] SUCCESS: Matched formatting rules for: "${providerUsed}" slip structure.`
      ]);
    }
  }, [detectedLegs]);

  useEffect(() => {
    if (!isAnalyzing) return;

    // Scroll to the bottom of the log screen whenever logs update
    if (consoleEndRef.current) {
      consoleEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isAnalyzing]);

  useEffect(() => {
    if (!isAnalyzing) return;

    let timeoutId: NodeJS.Timeout;
    
    // Staggered premium progression
    const runStage = (index: number) => {
      if (index >= STAGES.length) {
        if (onLoadingComplete) {
          onLoadingComplete();
        }
        return;
      }

      setCurrentStageIndex(index);

      // Append stage-specific hyper-realistic terminal logs
      const stageName = STAGES[index].title;
      const primarySportsbook = detectedLegs[0]?.sportsbookName || "Bet365 / Vouch";
      
      const newLogs: string[] = [];
      newLogs.push(`\n>>> STARTING STAGE: [${stageName.toUpperCase()}]`);

      switch (index) {
        case 0:
          newLogs.push(`[SYSTEM] Initializing image layout checks...`);
          newLogs.push(`[SYSTEM] Reading binary payload representing "${primarySportsbook}" slip structure.`);
          newLogs.push(`[SHARPEN] Applied premium 3x3 high-contrast convolution matrix.`);
          newLogs.push(`[SHARPEN] Enhanced letter borders and digit contours dynamically for flawless character parsing.`);
          break;
        case 1:
          newLogs.push(`[VISION] Calibrating character boundary matrices for optical character recognition...`);
          newLogs.push(`[VISION] Slicing text blocks and checking contrast levels.`);
          break;
        case 2:
          newLogs.push(`[VISION] Analyzing ticket header branding and color schemes...`);
          newLogs.push(`[VISION] Detected provider: ${primarySportsbook}`);
          break;
        case 3:
          newLogs.push(`[PARSER] Identifying parlay leg bounds...`);
          detectedLegs.forEach((leg, i) => {
            newLogs.push(`[PARSER] Leg #${i + 1} segmented: "${leg.rawText || (leg.playerName + ' ' + leg.line + ' ' + leg.market)}".`);
          });
          break;
        case 4:
          newLogs.push(`[ROSTER] Cross-referencing player profiles with active 2026 team databases...`);
          detectedLegs.forEach((leg) => {
            if (leg.playerName && leg.playerName !== "None") {
              newLogs.push(`[ROSTER] Matched: "${leg.playerName}" verified on active roster for "${leg.team}".`);
            }
          });
          break;
        case 5:
          newLogs.push(`[QUALITY] Computing confidence metric averages...`);
          newLogs.push(`[QUALITY] Checked bounding-box bounds and pixel densities.`);
          newLogs.push(`[QUALITY] Status: Over 95.0% confidence matched.`);
          break;
        case 6:
          newLogs.push(`[SYSTEM] Pipeline complete! Rendering structured list for user review...`);
          break;
      }

      setLogs((prev) => [...prev, ...newLogs]);

      // Trigger next stage
      timeoutId = setTimeout(() => {
        runStage(index + 1);
      }, STAGES[index].duration);
    };

    runStage(0);

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [isAnalyzing, onLoadingComplete, detectedLegs]);

  const progressPercent = Math.min(100, Math.round(((currentStageIndex + 1) / STAGES.length) * 100));
  const activeStage = STAGES[currentStageIndex] || STAGES[STAGES.length - 1];
  const ActiveIcon = activeStage.icon || Loader2;

  // Sportsbooks we cross-check visual layouts for
  const PROVIDERS = [
    { name: "Bet365", color: "text-emerald-400" },
    { name: "Vouch", color: "text-indigo-400" },
    { name: "DraftKings", color: "text-lime-400" },
    { name: "FanDuel", color: "text-blue-400" },
    { name: "Bovada", color: "text-rose-400" },
    { name: "MGM", color: "text-amber-400" }
  ];

  return (
    <div 
      className="w-full max-w-4xl mx-auto p-6 md:p-8 bg-slate-950/70 border border-slate-900 rounded-2xl relative overflow-hidden text-left shadow-2xl space-y-6"
      id="vouchscan-loading-premium"
    >
      {/* High-tech animated neon scan line */}
      <div className="absolute top-0 left-0 right-0 h-[2.5px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_rgba(34,211,238,0.8)] animate-scanline pointer-events-none z-20" />

      {/* Header and Stage Progress */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-900/60 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <h3 className="text-sm font-black text-slate-100 uppercase tracking-widest font-mono flex items-center gap-1.5">
              <span>VouchScan Premium Multi-Provider Audit</span>
              <span className="text-[10px] bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded font-bold">ACTIVE</span>
            </h3>
          </div>
          <p className="text-xs text-slate-400 font-medium mt-1">
            Parsing, validating rosters, starting pitchers, stadium weather, and correlation vectors.
          </p>
        </div>
        
        {/* Dynamic Sportsbook Layout Checkmarks */}
        <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-900/80">
          <span className="text-[8px] font-mono font-black text-slate-500 uppercase tracking-widest mr-1">SCRUBBING LAYOUTS:</span>
          <div className="flex flex-wrap gap-1.5">
            {PROVIDERS.map((p, idx) => (
              <span 
                key={idx}
                className={`text-[9px] font-mono px-1.5 py-0.5 rounded border border-slate-900 font-extrabold flex items-center gap-1 bg-slate-900/30 ${
                  currentStageIndex >= 1 ? `${p.color} border-slate-800` : 'text-slate-600'
                }`}
              >
                <span>{p.name}</span>
                {currentStageIndex >= 1 && <span className="w-1 h-1 rounded-full bg-current animate-pulse" />}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Dynamic Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Hand: Radial loader and current stage info */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
          <div className="bg-slate-900/30 border border-slate-900/60 p-6 rounded-2xl flex flex-col items-center text-center space-y-4">
            
            {/* Spinning Neon Circle Core */}
            <div className="relative w-24 h-24 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-4 border-slate-900" />
              <div 
                className="absolute inset-0 rounded-full border-4 border-cyan-400 border-t-transparent animate-spin" 
                style={{ animationDuration: '2s' }}
              />
              <div className="absolute inset-2 bg-slate-950 rounded-full flex flex-col items-center justify-center shadow-inner">
                <span className="text-xl font-black text-slate-100 font-mono tracking-tight">
                  {progressPercent}%
                </span>
                <span className="text-[8px] font-mono text-cyan-400 uppercase font-black tracking-widest">
                  Verifying
                </span>
              </div>
            </div>

            {/* Current Active Step */}
            <div className="space-y-1.5">
              <span className="text-[9px] font-mono font-black uppercase tracking-widest text-cyan-400 px-2 py-0.5 bg-cyan-500/10 border border-cyan-500/20 rounded">
                PIPELINE STEP {currentStageIndex + 1} OF {STAGES.length}
              </span>
              <h4 className="text-base font-extrabold text-slate-200 uppercase tracking-tight">
                {activeStage.title}
              </h4>
              <p className="text-xs text-slate-500 font-medium leading-relaxed px-2">
                {activeStage.sub}
              </p>
            </div>
          </div>

          {/* Today's Target Matches Checklist */}
          {detectedLegs.length > 0 && (
            <div className="bg-slate-900/30 border border-slate-900/60 p-5 rounded-2xl space-y-3">
              <div className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-cyan-400" />
                <span>CONFIRMING TARGET PROPS</span>
              </div>
              <div className="space-y-2">
                {detectedLegs.map((leg, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs bg-slate-950 p-2.5 rounded-xl border border-slate-900/50">
                    <div className="min-w-0 flex-1">
                      <div className="font-extrabold text-slate-200 flex items-center gap-1 truncate">
                        <span>{leg.playerName !== "None" ? leg.playerName : leg.team}</span>
                        <span className="text-[9px] font-mono text-slate-500">({leg.team})</span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-medium font-mono truncate">
                        {leg.line} {leg.market}
                      </div>
                    </div>
                    <span className="text-[9px] font-mono font-black px-2 py-0.5 bg-cyan-500/10 text-cyan-400 rounded-md border border-cyan-500/20 uppercase tracking-widest animate-pulse shrink-0">
                      CROSSING...
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Hand: Hacker-Style Interactive Terminal Output */}
        <div className="lg:col-span-7 flex flex-col bg-slate-950 border border-slate-900 rounded-2xl overflow-hidden aspect-square lg:aspect-auto lg:h-[450px]">
          {/* Terminal Titlebar */}
          <div className="bg-slate-900 p-3.5 border-b border-slate-900/80 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              </div>
              <span className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest">
                VouchScan_Vision_Console.sh
              </span>
            </div>
            <div className="flex items-center gap-2 text-[9px] font-mono text-slate-500">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>LIVE CORE API LINK</span>
            </div>
          </div>

          {/* Terminal Body */}
          <div className="flex-1 p-4 font-mono text-[11px] leading-relaxed text-slate-400 overflow-y-auto space-y-1.5 scrollbar-thin">
            {logs.map((log, index) => {
              let textClass = "text-slate-350";
              if (log.startsWith(">>> STARTING STAGE")) {
                textClass = "text-cyan-400 font-extrabold mt-3 border-l-2 border-cyan-400 pl-2 bg-cyan-500/5 py-1";
              } else if (log.includes("SUCCESS") || log.includes("verified") || log.includes("Stable")) {
                textClass = "text-emerald-400 font-medium";
              } else if (log.includes("ERROR") || log.includes("⚠️")) {
                textClass = "text-rose-400 font-black";
              } else if (log.startsWith("[VOUCH_JUDGE]") || log.includes("OPINION_ENGINE")) {
                textClass = "text-indigo-400 font-semibold";
              }

              return (
                <div key={index} className={`whitespace-pre-wrap ${textClass}`}>
                  {log}
                </div>
              );
            })}
            <div ref={consoleEndRef} />
          </div>

          {/* Terminal Console Status Bar */}
          <div className="bg-slate-900/50 p-2.5 border-t border-slate-900/80 text-[10px] font-mono text-slate-500 flex justify-between items-center">
            <span>PIPELINE RATE: ~1200ms/step</span>
            <span className="text-cyan-400 font-bold uppercase animate-pulse">Scanning live...</span>
          </div>
        </div>
      </div>
    </div>
  );
}
