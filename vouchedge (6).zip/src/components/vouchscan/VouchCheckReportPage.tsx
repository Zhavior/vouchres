import React, { useState } from 'react';
import { ShieldCheck, TrendingUp, CloudSun, AlertTriangle, Sparkles, Share2, Clipboard, ArrowRight, Zap, Trophy, HelpCircle, ChevronRight, Lock } from 'lucide-react';
import { VouchCheckReport, DetectedLeg, AgentReview } from '../../types/vouchscan';
import { CreatorProofProfile } from '../../types';

interface VouchCheckReportPageProps {
  report: VouchCheckReport;
  profile: CreatorProofProfile;
  onUpgradeClick?: () => void;
  onSaveAlternative?: (title: string, legs: any[], totalOdds: string) => void;
}

// 1. Premium Scan Gate to unlock deep metrics
export function PremiumScanGate({ 
  tierRequired, 
  userTier, 
  onUpgradeClick, 
  children 
}: { 
  tierRequired: 'PRO' | 'ELITE'; 
  userTier: 'BASIC' | 'GOLD' | 'SELLER_PRO'; 
  onUpgradeClick?: () => void; 
  children: React.ReactNode;
}) {
  const isUnlocked = 
    (tierRequired === 'PRO' && (userTier === 'GOLD' || userTier === 'SELLER_PRO')) ||
    (tierRequired === 'ELITE' && userTier === 'SELLER_PRO') ||
    userTier === 'SELLER_PRO' || // Seller Pro maps to Elite
    userTier === 'GOLD' && tierRequired === 'PRO'; // Gold maps to Pro

  if (isUnlocked) {
    return <>{children}</>;
  }

  return (
    <div className="relative rounded-2xl border border-slate-850 bg-slate-950/80 p-6 md:p-8 overflow-hidden text-center" id="premium-gate-container">
      {/* Blurred background content mockup */}
      <div className="opacity-15 pointer-events-none select-none blur-[4px]">
        {children}
      </div>

      {/* Lock Overlay */}
      <div className="absolute inset-0 flex flex-col items-center justify-center p-6 bg-slate-950/40 backdrop-blur-sm">
        <div className="p-3.5 rounded-full bg-gradient-to-br from-amber-500 to-rose-600 border border-amber-400 text-white shadow-[0_0_20px_rgba(245,158,11,0.3)] mb-4 animate-bounce">
          <Lock className="w-6 h-6" />
        </div>
        <div className="max-w-md mx-auto space-y-2">
          <h4 className="text-sm md:text-base font-extrabold text-slate-100 uppercase tracking-wider font-mono">
            🛡️ UNLOCK {tierRequired} LEVEL AUDIT
          </h4>
          <p className="text-xs text-slate-400 font-medium leading-relaxed">
            This detailed diagnostic (such as leg-by-leg metrics, pitcher weakness profiles, weather vectors, or the full capper consensus review) is locked on the standard Free tier.
          </p>
          <div className="pt-3">
            <button
              onClick={onUpgradeClick}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-extrabold text-xs uppercase tracking-wider shadow-lg transition-transform hover:scale-[1.03] active:scale-[0.98]"
            >
              🚀 Upgrade Plan to Unlock
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// 2. Big Vouch Score Circular Card
export function VouchScoreCard({ score, verdict }: { score: number; verdict: string }) {
  // Score colors
  let strokeColor = 'stroke-rose-500';
  let glowColor = 'shadow-rose-500/20';
  let textColor = 'text-rose-400';
  
  if (score >= 82) {
    strokeColor = 'stroke-emerald-500';
    textColor = 'text-emerald-400';
    glowColor = 'shadow-emerald-500/20';
  } else if (score >= 68) {
    strokeColor = 'stroke-cyan-500';
    textColor = 'text-cyan-400';
    glowColor = 'shadow-cyan-500/20';
  } else if (score >= 52) {
    strokeColor = 'stroke-amber-500';
    textColor = 'text-amber-400';
    glowColor = 'shadow-amber-500/20';
  }

  const radius = 60;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="bg-slate-900/60 border border-slate-850 p-6 rounded-2xl flex flex-col items-center justify-center text-center relative overflow-hidden" id="vouch-score-card">
      <div className="absolute top-0 left-0 bg-gradient-to-r from-indigo-500/5 to-cyan-500/5 w-full h-full pointer-events-none" />
      <h4 className="text-[10px] text-slate-400 font-black uppercase tracking-widest font-mono mb-4">
        OVERALL VOUCH SCORE
      </h4>

      {/* Radial Gauge */}
      <div className="relative w-36 h-36 flex items-center justify-center mb-4">
        <svg className="w-full h-full transform -rotate-90">
          {/* Background circle */}
          <circle 
            cx="72" 
            cy="72" 
            r={radius} 
            className="stroke-slate-850 fill-none" 
            strokeWidth="10" 
          />
          {/* Foreground progress */}
          <circle 
            cx="72" 
            cy="72" 
            r={radius} 
            className={`fill-none transition-all duration-1000 ${strokeColor}`}
            strokeWidth="10" 
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute flex flex-col items-center justify-center">
          <span className={`text-4xl font-black font-mono tracking-tighter ${textColor}`}>
            {score}
          </span>
          <span className="text-[9px] text-slate-500 font-extrabold uppercase font-mono">
            V-RATING
          </span>
        </div>
      </div>

      <div className="space-y-1 z-10">
        <span className="text-[10px] text-slate-500 font-bold uppercase font-mono">Verdict Suggestion</span>
        <div className={`px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-wider inline-block ${
          verdict === 'Tail' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
          verdict === 'Wait' ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' :
          verdict === 'Lotto Only' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
          verdict === 'Needs More Data' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
          'bg-rose-500/20 text-rose-400 border border-rose-500/30'
        }`}>
          🎯 {verdict}
        </div>
      </div>
    </div>
  );
}

// 3. AI Judge Scan Panel
export function JudgeScanPanel({ verdict, notes, whatCouldGoWrong }: { verdict: any; notes: string; whatCouldGoWrong: string }) {
  return (
    <div className="bg-slate-900/60 border border-slate-850 p-6 rounded-2xl space-y-4" id="judge-scan-panel">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-cyan-400" />
          <h4 className="text-xs font-black text-slate-200 uppercase tracking-wider font-mono">
            VOUCHEDGE JUDGE CONSENSUS
          </h4>
        </div>
        <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase font-mono border ${
          verdict.approvalStatus === 'Tail' ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/40' :
          verdict.approvalStatus === 'Wait' ? 'bg-cyan-950/40 text-cyan-400 border-cyan-800/40' :
          'bg-rose-950/40 text-rose-400 border-rose-800/40'
        }`}>
          {verdict.approvalStatus} APPROVED
        </span>
      </div>

      <p className="text-xs md:text-sm text-slate-300 leading-relaxed font-medium bg-slate-950/40 p-4 rounded-xl border border-slate-850/60">
        "{notes}"
      </p>

      {/* Checklist status items */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 pt-2">
        {[
          { label: "Pick Logic", checked: true },
          { label: "Leverage Limit", checked: verdict.parlayAllowed },
          { label: "Bias Clearance", checked: true },
          { label: "Data Quality", checked: true }
        ].map((item, idx) => (
          <div key={idx} className="bg-slate-950/30 border border-slate-850 rounded-lg px-3 py-2 flex items-center gap-2 text-[11px]">
            <span className={`w-2 h-2 rounded-full ${item.checked ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-rose-500 animate-ping'}`} />
            <span className="text-slate-400 font-bold uppercase font-mono">{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// 4. Agent Scan Panel
export function AgentScanPanel({ reviews }: { reviews: AgentReview[] }) {
  // Agent avatar colors
  const avatarColors: Record<string, string> = {
    professor: 'from-blue-600 to-indigo-700 text-blue-100 border-blue-500',
    hr_hunter: 'from-orange-500 to-rose-600 text-orange-100 border-orange-500',
    sharp_syndicate: 'from-emerald-600 to-teal-700 text-emerald-100 border-emerald-500',
    sneaky_dog: 'from-yellow-600 to-amber-700 text-amber-100 border-amber-500',
    parlay_demon: 'from-rose-600 to-red-800 text-rose-100 border-rose-500',
    trust_guardian: 'from-purple-600 to-fuchsia-700 text-purple-100 border-purple-500',
    result_teacher: 'from-sky-600 to-cyan-700 text-sky-100 border-cyan-500'
  };

  return (
    <div className="space-y-4" id="agent-scan-panel">
      <div className="flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-amber-400" />
        <h4 className="text-xs font-black text-slate-200 uppercase tracking-wider font-mono">
          AI AGENT DETAILED AUDITS
        </h4>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {reviews.map((rev) => {
          const colorClass = avatarColors[rev.agentId] || 'from-slate-600 to-slate-800 text-slate-100 border-slate-600';
          return (
            <div 
              key={rev.agentId}
              className="bg-slate-900/40 border border-slate-850 rounded-2xl p-4 flex flex-col justify-between group hover:border-slate-750 transition-all hover:-translate-y-0.5 duration-200"
              id={`agent-card-${rev.agentId}`}
            >
              <div className="space-y-3">
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${colorClass} flex items-center justify-center font-bold text-sm border-2 shrink-0 shadow-md`}>
                      {rev.agentName[0]}
                    </div>
                    <div>
                      <h5 className="text-xs font-extrabold text-slate-200 uppercase tracking-tight group-hover:text-cyan-400 transition-colors">
                        {rev.agentName}
                      </h5>
                      <p className="text-[9px] text-slate-500 font-mono font-bold leading-none uppercase mt-0.5">
                        {rev.role}
                      </p>
                    </div>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase font-mono ${
                    rev.verdict === 'Support' ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/40' :
                    rev.verdict === 'Caution' ? 'bg-amber-950/40 text-amber-400 border border-amber-800/40' :
                    'bg-slate-950 text-slate-500 border border-slate-850'
                  }`}>
                    {rev.verdict}
                  </span>
                </div>

                {/* Notes */}
                <p className="text-xs text-slate-400 font-medium leading-relaxed italic">
                  "{rev.notes}"
                </p>
              </div>

              {/* Stats Footer */}
              <div className="mt-4 pt-3 border-t border-slate-900/60 flex items-center justify-between text-[10px] font-mono text-slate-500">
                <span>CONFIDENCE: <strong className="text-slate-350">{rev.confidence}%</strong></span>
                <span>RISK: <strong className="text-rose-450">{rev.riskFactor}</strong></span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// 5. Leg Breakdown Card
export function LegBreakdownCard({ leg, stats, vulnerability, impact }: { leg: DetectedLeg; stats?: any; vulnerability?: any; impact?: any; key?: string }) {
  return (
    <div className="bg-slate-900/40 border border-slate-850 rounded-2xl p-4 space-y-4" id={`leg-breakdown-${leg.id}`}>
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-900/60">
        <div>
          <span className="px-2 py-0.5 bg-indigo-950/60 text-indigo-400 border border-indigo-800/40 rounded text-[9px] font-extrabold font-mono tracking-wide uppercase">
            ⚾ {leg.sport} PROP
          </span>
          <h4 className="text-sm font-black text-slate-100 tracking-tight mt-1">
            {leg.playerName !== 'None' ? leg.playerName : 'Game Line Matchup'}
          </h4>
          <p className="text-[10px] text-slate-400 font-medium mt-0.5 uppercase tracking-wider">
            {leg.team} vs {leg.opponent}
          </p>
        </div>
        <div className="text-right">
          <div className="text-xs font-bold text-slate-400 font-mono uppercase tracking-wider">{leg.market}</div>
          <div className="text-sm font-black text-cyan-400 font-mono mt-0.5">{leg.line} ({leg.odds})</div>
        </div>
      </div>

      {/* Multi-metrics layout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
        {/* Stats */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
            <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
            <span>SEASON STATS</span>
          </div>
          {stats ? (
            <div className="bg-slate-950/40 rounded-xl p-3 border border-slate-900/60 space-y-2">
              <div className="grid grid-cols-4 gap-1 text-center">
                <div className="p-1 bg-slate-900/40 rounded">
                  <div className="text-[9px] text-slate-500 font-mono font-bold">AVG</div>
                  <div className="text-xs font-bold text-slate-200 font-mono">{stats.avg}</div>
                </div>
                <div className="p-1 bg-slate-900/40 rounded">
                  <div className="text-[9px] text-slate-500 font-mono font-bold">HR</div>
                  <div className="text-xs font-bold text-slate-200 font-mono">{stats.hr}</div>
                </div>
                <div className="p-1 bg-slate-900/40 rounded">
                  <div className="text-[9px] text-slate-500 font-mono font-bold">RBI</div>
                  <div className="text-xs font-bold text-slate-200 font-mono">{stats.rbi}</div>
                </div>
                <div className="p-1 bg-slate-900/40 rounded">
                  <div className="text-[9px] text-slate-500 font-mono font-bold">OPS</div>
                  <div className="text-xs font-bold text-slate-200 font-mono">{stats.ops}</div>
                </div>
              </div>
              <p className="text-[11px] text-slate-400 font-semibold leading-relaxed font-sans italic">
                "{stats.recentTrend}"
              </p>
            </div>
          ) : (
            <div className="text-xs text-slate-500 font-mono italic">No stats linked</div>
          )}
        </div>

        {/* Pitcher Vulnerability */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
            <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>MATCHUP VULNERABILITY</span>
          </div>
          {vulnerability ? (
            <div className="bg-slate-950/40 rounded-xl p-3 border border-slate-900/60 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-slate-300">{vulnerability.pitcherName} ({vulnerability.team})</span>
                <span className="text-[10px] text-rose-400 font-extrabold font-mono uppercase bg-rose-950/30 px-1.5 rounded">
                  {vulnerability.vulnerabilityScore}% RISK
                </span>
              </div>
              <p className="text-[11px] text-slate-450 leading-relaxed font-medium">
                {vulnerability.vulnerabilityNotes}
              </p>
            </div>
          ) : (
            <div className="text-xs text-slate-500 font-mono italic">No pitcher profile linked</div>
          )}
        </div>

        {/* Weather Park */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
            <CloudSun className="w-3.5 h-3.5 text-amber-400" />
            <span>WEATHER & PARK FACTORS</span>
          </div>
          {impact ? (
            <div className="bg-slate-950/40 rounded-xl p-3 border border-slate-900/60 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-slate-300">{impact.parkFactor}</span>
                <span className={`text-[10px] font-extrabold font-mono px-1.5 rounded ${
                  impact.impactScore > 0 ? 'bg-emerald-950/30 text-emerald-400' : 'bg-rose-950/30 text-rose-400'
                }`}>
                  {impact.impactScore > 0 ? `+${impact.impactScore}` : impact.impactScore} INDEX
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed font-semibold">
                {impact.wind} • {impact.temperature} • {impact.impactNotes}
              </p>
            </div>
          ) : (
            <div className="text-xs text-slate-500 font-mono italic">No weather model linked</div>
          )}
        </div>
      </div>
    </div>
  );
}

// 6. What Could Go Wrong Card
export function WhatCouldGoWrongCard({ risks }: { risks: string[] }) {
  return (
    <div className="bg-[#0b0404]/90 border border-red-950 p-6 rounded-2xl space-y-3.5 text-left" id="what-could-go-wrong-card">
      <div className="flex items-center gap-2">
        <AlertTriangle className="w-5 h-5 text-rose-500" />
        <h4 className="text-xs font-black text-rose-200 uppercase tracking-wider font-mono">
          WHAT COULD GO WRONG?
        </h4>
      </div>
      <ul className="space-y-2">
        {risks.map((risk, idx) => (
          <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-350 leading-relaxed font-medium">
            <span className="text-rose-500 mt-0.5 select-none shrink-0">•</span>
            <span>{risk}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// 7. Safer Alternative Card
export function SaferAlternativeCard({ 
  alternative, 
  onSaveAlternative 
}: { 
  alternative: any; 
  onSaveAlternative?: (title: string, legs: any[], totalOdds: string) => void;
}) {
  const [isSaved, setIsSaved] = useState(false);

  const handleVouchSafer = () => {
    if (!onSaveAlternative) return;

    // Map to regular Leg type
    const parlayLegs = alternative.legs.map((l: any, idx: number) => ({
      id: `safer-leg-${Date.now()}-${idx}`,
      sport: "MLB",
      game: "MLB Safe Match",
      market: "To Record 1+ Hits",
      selection: l.saferSelection,
      odds: -200,
      status: 'PENDING'
    }));

    onSaveAlternative(
      "VouchScan Safer Parlay",
      parlayLegs,
      alternative.saferOdds
    );

    setIsSaved(true);
  };

  return (
    <div className="bg-gradient-to-r from-emerald-950/20 via-slate-900/90 to-slate-950 border border-emerald-500/40 p-6 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6 text-left relative overflow-hidden" id="safer-alternative-card">
      <div className="absolute top-0 right-0 p-1 bg-emerald-500 text-slate-950 text-[8px] font-black uppercase tracking-widest font-mono rounded-bl-xl rotate-1">
        ★ RECOMMENDED ALTERNATIVE
      </div>

      <div className="space-y-3 flex-1">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-emerald-400" />
          <h4 className="text-xs font-black text-emerald-400 uppercase tracking-wider font-mono">
            VOUCHED SAFEST VALUE ADJUSTMENT
          </h4>
        </div>
        
        <p className="text-xs text-slate-300 font-medium leading-relaxed max-w-xl">
          We converted high-variance batting markers into basic contact logs. This waters down the payout odds but multiplies implied hit probability by over <strong className="text-emerald-400 font-bold">185%</strong>.
        </p>

        {/* Detailed Legs Comparer */}
        <div className="space-y-2.5 pt-1.5">
          {alternative.legs.map((leg: any, idx: number) => (
            <div key={idx} className="bg-slate-950/60 border border-slate-900 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="min-w-0">
                <span className="text-slate-450 font-bold uppercase block truncate leading-none mb-1 text-[10px]">
                  {leg.originalSelection.split(' ')[0]} PROPOSITION
                </span>
                <span className="text-slate-400 font-semibold line-through block truncate">{leg.originalSelection}</span>
                <span className="text-emerald-400 font-extrabold block truncate mt-0.5">➔ {leg.saferSelection}</span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono italic max-w-[200px] leading-tight">
                {leg.reason}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Action panel */}
      <div className="bg-slate-950/60 border border-slate-850 p-4 rounded-xl text-center shrink-0 w-full md:w-[220px] flex flex-col justify-between h-full">
        <div className="space-y-1 mb-4">
          <div className="text-[9px] text-slate-500 font-black uppercase tracking-widest font-mono">ODDS TRANSITION</div>
          <div className="flex items-center justify-center gap-2.5">
            <span className="text-sm font-bold text-slate-400 line-through font-mono">{alternative.originalOdds}</span>
            <ArrowRight className="w-4 h-4 text-slate-500" />
            <span className="text-xl font-black text-emerald-400 font-mono">{alternative.saferOdds}</span>
          </div>
        </div>

        <button
          onClick={handleVouchSafer}
          disabled={isSaved}
          className={`w-full py-2.5 px-4 rounded-xl text-xs font-black uppercase tracking-widest transition-transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-1.5 ${
            isSaved 
              ? 'bg-emerald-950 border border-emerald-800 text-emerald-400 cursor-default' 
              : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/10'
          }`}
        >
          {isSaved ? (
            <>
              <ShieldCheck className="w-4 h-4" />
              <span>SAVED TO SLIPS</span>
            </>
          ) : (
            <>
              <Zap className="w-4 h-4" />
              <span>Vouch Alternative</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}

export default function VouchCheckReportPage({ 
  report, 
  profile, 
  onUpgradeClick,
  onSaveAlternative 
}: VouchCheckReportPageProps) {
  const [copySuccess, setCopySuccess] = useState(false);

  const handleShareReport = () => {
    // Generate a simple share link
    const shareUrl = `${window.location.origin}/vouchcheck/${report.shareToken}`;
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  return (
    <div className="space-y-6 text-left" id="vouch-check-report-page">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-950/30 p-4 rounded-xl border border-slate-900/60">
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400 font-black tracking-widest uppercase">
            <span>AUDITED VOUCHCHECK REPORT</span>
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span>ID: {report.id}</span>
          </div>
          <h2 className="text-lg font-black text-slate-100 uppercase tracking-tight mt-1">
            PARLAY RISK ANALYSIS SUMMARY
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleShareReport}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5"
            id="share-report-button"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{copySuccess ? 'Copied!' : 'Share Report'}</span>
          </button>
        </div>
      </div>

      {/* Main split grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Overall Vouch Score */}
        <div className="lg:col-span-1">
          <VouchScoreCard score={report.overallVouchScore} verdict={report.verdict} />
        </div>

        {/* Right Column: AI Judge Consensus */}
        <div className="lg:col-span-2">
          <JudgeScanPanel 
            verdict={report.judgeVerdict} 
            notes={report.judgeVerdict.judgeNotes} 
            whatCouldGoWrong={report.judgeVerdict.whatCouldGoWrong} 
          />
        </div>
      </div>

      {/* Safer alternative row */}
      <SaferAlternativeCard alternative={report.saferAlternative} onSaveAlternative={onSaveAlternative} />

      {/* Leg breakdown section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-black text-slate-350 uppercase tracking-widest font-mono">
            LEG-BY-LEG RISK PROFILES
          </h3>
          <span className="text-[10px] font-mono text-slate-500 font-bold uppercase">
            {report.legs.length} LEGS AUDITED
          </span>
        </div>

        <div className="space-y-4">
          {report.legs.map((leg, index) => {
            const legStats = report.playerStats[index];
            const legVulnerability = report.pitcherVulnerability[index];
            const legImpact = report.weatherParkImpact[index];

            return (
              <LegBreakdownCard 
                key={leg.id}
                leg={leg}
                stats={legStats}
                vulnerability={legVulnerability}
                impact={legImpact}
              />
            );
          })}
        </div>
      </div>

      {/* Premium Gated Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Correlation Risk */}
        <div className="space-y-2">
          <h4 className="text-[10px] text-slate-400 font-black uppercase tracking-widest font-mono">
            CORRELATION SAFETY ANALYSIS
          </h4>
          <PremiumScanGate tierRequired="PRO" userTier={profile.subscriptionTier || 'BASIC'} onUpgradeClick={onUpgradeClick}>
            <div className={`p-5 rounded-2xl border ${
              report.correlationRisk.isNegativeCorrelation 
                ? 'bg-rose-950/20 border-rose-500/40 text-rose-200' 
                : 'bg-emerald-950/20 border-emerald-500/40 text-emerald-200'
            }`}>
              <h5 className="text-xs font-extrabold uppercase tracking-wider font-mono flex items-center gap-1.5">
                <span>RISK LEVEL: {report.correlationRisk.riskLevel}</span>
              </h5>
              <p className="text-xs text-slate-300 leading-relaxed font-medium mt-2">
                {report.correlationRisk.description}
              </p>
            </div>
          </PremiumScanGate>
        </div>

        {/* What could go wrong */}
        <div className="space-y-2">
          <h4 className="text-[10px] text-slate-400 font-black uppercase tracking-widest font-mono">
            EXTREME SCENARIO DRIFT
          </h4>
          <PremiumScanGate tierRequired="PRO" userTier={profile.subscriptionTier || 'BASIC'} onUpgradeClick={onUpgradeClick}>
            <WhatCouldGoWrongCard risks={report.whatCouldGoWrong} />
          </PremiumScanGate>
        </div>
      </div>

      {/* Agent detailed consensus reviews (Elite gate) */}
      <div className="space-y-2">
        <h4 className="text-[10px] text-slate-400 font-black uppercase tracking-widest font-mono">
          CONSENSUS COMMITTEE REVIEWS
        </h4>
        <PremiumScanGate tierRequired="ELITE" userTier={profile.subscriptionTier || 'BASIC'} onUpgradeClick={onUpgradeClick}>
          <AgentScanPanel reviews={report.agentReviews} />
        </PremiumScanGate>
      </div>
    </div>
  );
}
