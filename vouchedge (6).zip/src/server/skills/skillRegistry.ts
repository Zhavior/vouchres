import { SkillConfig } from './skillTypes';

// Reusable mock database to drive deterministic skills
const MLB_TEAMS = ['Yankees', 'Red Sox', 'Dodgers', 'Giants', 'Cubs', 'Cardinals', 'Astros', 'Braves', 'Mets', 'Phillies'];
const PITCHERS = [
  { name: 'Gerrit Cole', team: 'Yankees', hand: 'RHP', era: 3.12, hrAllowedRate: 'Low', vulnerability: 25 },
  { name: 'Carlos Rodon', team: 'Yankees', hand: 'LHP', era: 4.21, hrAllowedRate: 'Medium', vulnerability: 55 },
  { name: 'Dylan Cease', team: 'Padres', hand: 'RHP', era: 3.85, hrAllowedRate: 'High', vulnerability: 80 },
  { name: 'Max Fried', team: 'Braves', hand: 'LHP', era: 2.95, hrAllowedRate: 'Low', vulnerability: 18 },
  { name: 'Patrick Corbin', team: 'Nationals', hand: 'LHP', era: 5.62, hrAllowedRate: 'Very High', vulnerability: 95 }
];
const PLAYERS = [
  { name: 'Aaron Judge', team: 'Yankees', iso: 0.312, powerVsRhp: 92, powerVsLhp: 98, rbiPosition: 'Clean-up' },
  { name: 'Juan Soto', team: 'Yankees', iso: 0.254, powerVsRhp: 88, powerVsLhp: 85, rbiPosition: 'Third' },
  { name: 'Shohei Ohtani', team: 'Dodgers', iso: 0.325, powerVsRhp: 99, powerVsLhp: 91, rbiPosition: 'Second' },
  { name: 'Kyle Schwarber', team: 'Phillies', iso: 0.288, powerVsRhp: 94, powerVsLhp: 72, rbiPosition: 'Lead-off' },
  { name: 'Pete Alonso', team: 'Mets', iso: 0.265, powerVsRhp: 82, powerVsLhp: 93, rbiPosition: 'Clean-up' },
  { name: 'Sneaky Sal', team: 'Cubs', iso: 0.210, powerVsRhp: 75, powerVsLhp: 88, rbiPosition: 'Seventh' } // Sneaky HR Target
];

export const SKILL_REGISTRY: Record<string, SkillConfig> = {
  fetchTodaysGames: {
    id: 'fetchTodaysGames',
    name: 'Fetch Today\'s MLB Games',
    description: 'Retrieves today\'s scheduled baseball fixtures and their associated metadata.',
    category: 'data_fetching',
    inputSchema: { date: 'string (YYYY-MM-DD, default today)' },
    outputSchema: { games: 'Array of game objects' },
    enabled: true,
    run: async (inputs: { date?: string }) => {
      const date = inputs.date || '2026-06-24';
      return {
        games: [
          { gameId: 'g-mlb-1', homeTeam: 'Yankees', awayTeam: 'Red Sox', time: '19:05 EST', parkFactor: 1.15, weather: 'Warm & humid' },
          { gameId: 'g-mlb-2', homeTeam: 'Dodgers', awayTeam: 'Giants', time: '22:10 EST', parkFactor: 0.98, weather: 'Clear & cool' },
          { gameId: 'g-mlb-3', homeTeam: 'Braves', awayTeam: 'Phillies', time: '19:20 EST', parkFactor: 1.05, weather: 'Slight wind outward' }
        ],
        date
      };
    }
  },

  fetchProbablePitchers: {
    id: 'fetchProbablePitchers',
    name: 'Fetch Probable Pitchers',
    description: 'Retrieves designated starting pitchers and historical stat overlays.',
    category: 'data_fetching',
    inputSchema: { gameId: 'string' },
    outputSchema: { pitchers: 'Array of starter details' },
    enabled: true,
    run: async (inputs: { gameId: string }) => {
      if (inputs.gameId === 'g-mlb-2') {
        return {
          pitchers: [
            { name: 'Yoshinobu Yamamoto', team: 'Dodgers', era: 2.85, hand: 'RHP' },
            { name: 'Logan Webb', team: 'Giants', era: 3.20, hand: 'RHP' }
          ]
        };
      }
      return {
        pitchers: [
          { name: 'Carlos Rodon', team: 'Yankees', era: 4.21, hand: 'LHP' },
          { name: 'Patrick Corbin', team: 'Nationals', era: 5.62, hand: 'LHP' }
        ]
      };
    }
  },

  fetchGameFeed: {
    id: 'fetchGameFeed',
    name: 'Fetch Real-Time Game Feed',
    description: 'Pulls the play-by-play status logs of a requested game.',
    category: 'data_fetching',
    inputSchema: { gameId: 'string' },
    outputSchema: { playByPlay: 'Array of events', inning: 'number', state: 'string' },
    enabled: true,
    run: async (inputs: { gameId: string }) => {
      return {
        gameId: inputs.gameId,
        inning: 4,
        state: 'Mid-4th',
        playByPlay: [
          { batter: 'Aaron Judge', description: 'Single to deep left field.' },
          { batter: 'Juan Soto', description: 'Walked on full count.' },
          { batter: 'Giancarlo Stanton', description: 'Strikeout swinging.' }
        ]
      };
    }
  },

  normalizeMlbGame: {
    id: 'normalizeMlbGame',
    name: 'Normalize MLB Game Data',
    description: 'Cleans, standardizes, and binds disparate team name codes across major sportsbook feeds.',
    category: 'data_fetching',
    inputSchema: { rawFeed: 'object' },
    outputSchema: { standardizedGame: 'object' },
    enabled: true,
    run: async (inputs: { rawFeed?: any }) => {
      return {
        standardizedGame: {
          awayTeam: 'Yankees',
          homeTeam: 'Red Sox',
          venue: 'Fenway Park',
          neutralVenue: false
        }
      };
    }
  },

  scorePitcherVulnerability: {
    id: 'scorePitcherVulnerability',
    name: 'Score Pitcher Vulnerability',
    description: 'Evaluates the starting pitcher\'s risk factors including home-run rates and ERA spikes.',
    category: 'mlb_analytics',
    inputSchema: { pitcherName: 'string' },
    outputSchema: { vulnerabilityScore: 'number', matchingGrade: 'string' },
    enabled: true,
    run: async (inputs: { pitcherName: string }) => {
      const match = PITCHERS.find(p => p.name.toLowerCase() === inputs.pitcherName.toLowerCase());
      const score = match ? match.vulnerability : 50;
      return {
        vulnerabilityScore: score,
        matchingGrade: score > 75 ? 'Critically Vulnerable' : score > 45 ? 'Moderately Exploitable' : 'Resilient'
      };
    }
  },

  rankHrTargets: {
    id: 'rankHrTargets',
    name: 'Rank Home-Run Targets',
    description: 'Ranks batters based on power variables matching the pitcher\'s throwing arm direction.',
    category: 'mlb_analytics',
    inputSchema: { opponentPitcherHand: 'RHP | LHP' },
    outputSchema: { rankedBatters: 'Array of players' },
    enabled: true,
    run: async (inputs: { opponentPitcherHand?: 'RHP' | 'LHP' }) => {
      const hand = inputs.opponentPitcherHand || 'RHP';
      const ranked = [...PLAYERS].sort((a, b) => {
        const valA = hand === 'RHP' ? a.powerVsRhp : a.powerVsLhp;
        const valB = hand === 'RHP' ? b.powerVsRhp : b.powerVsLhp;
        return valB - valA;
      });
      return { rankedBatters: ranked };
    }
  },

  findSneakyHrTargets: {
    id: 'findSneakyHrTargets',
    name: 'Find Sneaky HR Targets',
    description: 'Filters for under-the-radar batting power spikes that other sportsbooks miss.',
    category: 'mlb_analytics',
    inputSchema: { minIso: 'number' },
    outputSchema: { sneakyTargets: 'Array of players' },
    enabled: true,
    run: async (inputs: { minIso?: number }) => {
      const minIso = inputs.minIso || 0.200;
      const filtered = PLAYERS.filter(p => p.iso >= minIso && p.name.includes('Sneaky') || p.iso < 0.250);
      return { sneakyTargets: filtered };
    }
  },

  rankRbiTargets: {
    id: 'rankRbiTargets',
    name: 'Rank RBI Targets',
    description: 'Analyzes middle-of-the-order batters on active high-scoring team lineups.',
    category: 'mlb_analytics',
    inputSchema: { teamName: 'string' },
    outputSchema: { rbiTargets: 'Array of batters' },
    enabled: true,
    run: async (inputs: { teamName: string }) => {
      const filtered = PLAYERS.filter(p => p.team.toLowerCase() === inputs.teamName.toLowerCase());
      return { rbiTargets: filtered };
    }
  },

  scoreRunEnvironment: {
    id: 'scoreRunEnvironment',
    name: 'Score Run Environment',
    description: 'Calculates the overall park multiplier combining stadium dimensions, altitude, and current weather.',
    category: 'mlb_analytics',
    inputSchema: { stadiumName: 'string', windSpeedMph: 'number', windDirection: 'string' },
    outputSchema: { totalRunMultiplier: 'number', windHinder: 'boolean' },
    enabled: true,
    run: async (inputs: { stadiumName: string, windSpeedMph?: number, windDirection?: string }) => {
      const multiplier = inputs.stadiumName === 'Coors Field' ? 1.35 : 1.05;
      return {
        totalRunMultiplier: multiplier,
        windHinder: inputs.windDirection === 'inwards'
      };
    }
  },

  buildParlay: {
    id: 'buildParlay',
    name: 'Build High-Margin Parlay',
    description: 'Assembles multiple value legs into a high-yielding combined bet slip.',
    category: 'parlay_building',
    inputSchema: { legCount: 'number', riskPref: 'string' },
    outputSchema: { legs: 'Array of leg details', totalOdds: 'string' },
    enabled: true,
    run: async (inputs: { legCount?: number, riskPref?: string }) => {
      const legs = [
        { team: 'Yankees', market: 'Moneyline', odds: '-150' },
        { team: 'Aaron Judge', market: 'Over 1.5 Hits', odds: '+110' },
        { team: 'Dodgers vs Giants', market: 'Over 8.5 Runs', odds: '-110' }
      ].slice(0, inputs.legCount || 3);
      return {
        legs,
        totalOdds: '+420'
      };
    }
  },

  checkParlayCorrelation: {
    id: 'checkParlayCorrelation',
    name: 'Verify Parlay Correlation Match',
    description: 'Grades the logical synergy/overlap between legs to ensure they reinforce each other.',
    category: 'parlay_building',
    inputSchema: { legs: 'Array of legs' },
    outputSchema: { passesCheck: 'boolean', jointCorrelationScore: 'number' },
    enabled: true,
    run: async (inputs: { legs?: any[] }) => {
      return {
        passesCheck: true,
        jointCorrelationScore: 88
      };
    }
  },

  judgePick: {
    id: 'judgePick',
    name: 'Run Judge Review',
    description: 'Dispatches betting slips directly to standard or design auditors for a final risk verdict.',
    category: 'grading_trust',
    inputSchema: { pickDetails: 'object' },
    outputSchema: { finalReviewOutput: 'object' },
    enabled: true,
    run: async (inputs: { pickDetails?: any }) => {
      return {
        finalReviewOutput: {
          verdict: 'Approved',
          safetyBuffer: 'Good',
          flags: []
        }
      };
    }
  },

  explainPick: {
    id: 'explainPick',
    name: 'Explain Pick Rationale',
    description: 'Formulates clear, professional structural rationale highlighting what could go wrong.',
    category: 'grading_trust',
    inputSchema: { pickDetails: 'object' },
    outputSchema: { writtenExplanation: 'string', dangers: 'string' },
    enabled: true,
    run: async (inputs: { pickDetails?: any }) => {
      return {
        writtenExplanation: 'The starting pitcher has allowed 5 home runs in his last two games, matching Aaron Judge\'s strong power metrics.',
        dangers: 'Severe late bullpen collapse, or dynamic game rainout/delay.'
      };
    }
  },

  createDailyMlbReport: {
    id: 'createDailyMlbReport',
    name: 'Formulate Daily MLB Report',
    description: 'Aggregates multiple metrics into a comprehensive analytical market summary.',
    category: 'mlb_analytics',
    inputSchema: { date: 'string' },
    outputSchema: { markdownReport: 'string' },
    enabled: true,
    run: async (inputs: { date?: string }) => {
      return {
        markdownReport: `### Daily MLB Analytics Report - ${inputs.date || '2026-06-24'}\n` +
          `- **Best Stadium Environment**: Coors Field (High altitude, dry air)\n` +
          `- **Pitcher Vulnerability Spot**: Nationals starting rotation vs powerhouse teams\n` +
          `- **High-Yield Spot**: Underdog Run Line plays look highly undervalued.`
      };
    }
  },

  gradeResult: {
    id: 'gradeResult',
    name: 'Grade Outcome Result',
    description: 'Resolves completed match records and grades active betting slips.',
    category: 'grading_trust',
    inputSchema: { pickId: 'string', officialScore: 'string' },
    outputSchema: { payoutStatus: 'WIN | LOSS | PUSH', unitsNet: 'number' },
    enabled: true,
    run: async (inputs: { pickId: string, officialScore?: string }) => {
      return {
        payoutStatus: 'WIN',
        unitsNet: 2.5
      };
    }
  },

  createLearningNote: {
    id: 'createLearningNote',
    name: 'Create Post-Game Learning Note',
    description: 'Extracts constructive teaching lessons from historic betting wins or losses.',
    category: 'grading_trust',
    inputSchema: { gameResult: 'object', predictedPick: 'object' },
    outputSchema: { learningNote: 'string' },
    enabled: true,
    run: async (inputs: { gameResult?: any, predictedPick?: any }) => {
      return {
        learningNote: 'Patience paid off. The team had rest superiority, which became evident when their fresh bullpen closed out the late innings safely.'
      };
    }
  },

  updateTrustScore: {
    id: 'updateTrustScore',
    name: 'Recalculate User Trust Score',
    description: 'Puts the updated match outcome into the trust matrix, returning a live performance tier.',
    category: 'grading_trust',
    inputSchema: { currentScore: 'number', wonUnits: 'number', lostUnits: 'number' },
    outputSchema: { newTrustScore: 'number', trustLevel: 'string' },
    enabled: true,
    run: async (inputs: { currentScore: number, wonUnits: number, lostUnits: number }) => {
      const ratio = inputs.wonUnits / (inputs.lostUnits + 1);
      const score = Math.min(100, Math.max(0, inputs.currentScore + ratio));
      return {
        newTrustScore: score,
        trustLevel: score > 85 ? 'ELITE' : score > 60 ? 'TRUSTED' : 'UNVERIFIED'
      };
    }
  },

  generateProfileBadge: {
    id: 'generateProfileBadge',
    name: 'Issue Profile Reward Badge',
    description: 'Awards exclusive badges to players hitting specific platform engagement thresholds.',
    category: 'profile_rewards',
    inputSchema: { username: 'string', achievementCode: 'string' },
    outputSchema: { badgeAwarded: 'object', status: 'string' },
    enabled: true,
    run: async (inputs: { username: string, achievementCode: string }) => {
      return {
        status: 'AWARDED',
        badgeAwarded: {
          id: 'vouch_champion',
          name: 'Vouch Champion',
          icon: '👑',
          description: 'Earned by generating 5+ consecutive verified approvals in a single week.'
        }
      };
    }
  }
};

export function getSkillConfig(skillId: string): SkillConfig | undefined {
  return SKILL_REGISTRY[skillId];
}

export function getAllSkills(): SkillConfig[] {
  return Object.values(SKILL_REGISTRY);
}
