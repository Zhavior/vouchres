import { getSkillConfig } from './skillRegistry';

export async function runSkill(skillId: string, inputs: any = {}): Promise<any> {
  const skill = getSkillConfig(skillId);
  if (!skill) {
    throw new Error(`Skill with ID "${skillId}" not found in VouchEdge registry.`);
  }

  if (!skill.enabled) {
    throw new Error(`Skill with ID "${skillId}" is currently disabled.`);
  }

  try {
    // Run the skill
    const result = await skill.run(inputs);
    return result;
  } catch (error: any) {
    console.error(`Error running VouchEdge skill "${skillId}":`, error);
    throw new Error(`Failed running skill "${skillId}": ${error.message}`);
  }
}
