export interface SkillConfig {
  id: string;
  name: string;
  description: string;
  category: 'data_fetching' | 'mlb_analytics' | 'parlay_building' | 'grading_trust' | 'profile_rewards';
  inputSchema: Record<string, string>; // Input key to type descriptions
  outputSchema: Record<string, string>; // Output key to type descriptions
  enabled: boolean;
  run: (inputs: any) => Promise<any>;
}
