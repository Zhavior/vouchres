export interface CacheEntry<T> {
  value: T;
  expiry: number;
}

const cacheStore = new Map<string, CacheEntry<any>>();

/**
 * Creates a unique cache key based on function parameters or target objects.
 */
export function createCacheKey(prefix: string, ...args: any[]): string {
  return `${prefix}:${args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : String(arg)).join(':')}`;
}

/**
 * Fetches from cache or resolves the function if missing/expired.
 */
export async function simpleTtlCache<T>(
  key: string,
  resolveFn: () => Promise<T>,
  ttlMs: number = 300000 // default 5 minutes
): Promise<T> {
  const now = Date.now();
  const cached = cacheStore.get(key);

  if (cached && cached.expiry > now) {
    return cached.value as T;
  }

  const freshValue = await resolveFn();
  cacheStore.set(key, {
    value: freshValue,
    expiry: now + ttlMs
  });

  return freshValue;
}

/**
 * Clear the current cache (useful for debugging/testing).
 */
export function clearCache(): void {
  cacheStore.clear();
}
