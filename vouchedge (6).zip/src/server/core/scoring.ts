export function clampScore(score: number, min: number = 1, max: number = 100): number {
  return Math.max(min, Math.min(max, score));
}

export function scoreToTier(score: number): 'Elite' | 'Strong' | 'Average' | 'Speculative' | 'Substandard' {
  if (score >= 90) return 'Elite';
  if (score >= 75) return 'Strong';
  if (score >= 50) return 'Average';
  if (score >= 30) return 'Speculative';
  return 'Substandard';
}

export function scoreToRiskLabel(score: number): 'Safe' | 'Balanced' | 'Risky' | 'Sneaky' | 'Lotto' {
  if (score >= 85) return 'Safe';
  if (score >= 65) return 'Balanced';
  if (score >= 45) return 'Sneaky';
  if (score >= 25) return 'Risky';
  return 'Lotto';
}

export function getApprovalStatus(score: number): 'Approved' | 'Playable but risky' | 'Needs more data' | 'Avoid' {
  if (score >= 75) return 'Approved';
  if (score >= 50) return 'Playable but risky';
  if (score >= 30) return 'Needs more data';
  return 'Avoid';
}
