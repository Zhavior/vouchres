interface TermReplacement {
  pattern: RegExp;
  replacement: string;
}

const SAFETY_REPLACEMENTS: TermReplacement[] = [
  { pattern: /\block\b/gi, replacement: 'high-confidence pick' },
  { pattern: /\bguaranteed\b/gi, replacement: 'highly likely' },
  { pattern: /\bfree money\b/gi, replacement: 'strong mathematical edge' },
  { pattern: /\bcan't lose\b/gi, replacement: 'high probability outcome' },
  { pattern: /\b100% winner\b/gi, replacement: '90%+ confidence estimate' },
  { pattern: /\binsider fixed pick\b/gi, replacement: 'data-grounded valuation' },
  { pattern: /\bsure thing\b/gi, replacement: 'well-supported play' },
  { pattern: /\bmax bet\b/gi, replacement: 'allocated size recommendation' },
  { pattern: /\beasy win\b/gi, replacement: 'favorable matchup grade' }
];

/**
 * Replaces unpermitted betting hype terms with compliant, objective sports language.
 */
export function sanitizeBettingLanguage(text: string): string {
  if (!text) return '';
  let sanitized = text;
  for (const { pattern, replacement } of SAFETY_REPLACEMENTS) {
    sanitized = sanitized.replace(pattern, replacement);
  }
  return sanitized;
}
