/**
 * Prevents HTML injections and cleans input strings safely.
 */
export function escapeHtml(unsafe: string): string {
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

/**
 * Truncates text safely to a specified boundary.
 */
export function truncateSafe(text: string, maxLength: number = 200): string {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength - 3) + '...';
}

/**
 * Strips special markdown characters if a clean human text presentation is needed.
 */
export function stripMarkdown(md: string): string {
  if (!md) return '';
  return md
    .replace(/(\*\*|__)(.*?)\1/g, '$2')
    .replace(/(\*|_)(.*?)\1/g, '$2')
    .replace(/\[(.*?)\]\((.*?)\)/g, '$1')
    .replace(/`{1,3}(.*?)\1/g, '$1')
    .replace(/^#+\s+/gm, '');
}
