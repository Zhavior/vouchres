export interface JudgeConfig {
  id: string;
  name: string;
  description: string;
  weight: number; // 0.0 to 1.0 influence
  checks: string[]; // Specific check parameters
  outputFields: string[]; // Expected fields in output
  category: 'sports_logic' | 'bias_risk' | 'data_integrity' | 'ui_design';
}

export interface IndividualJudgeResult {
  judgeId: string;
  judgeName: string;
  score: number; // 1-100
  status: 'Approved' | 'Playable but risky' | 'Needs more data' | 'Avoid';
  riskLabel: 'Safe' | 'Balanced' | 'Risky' | 'Sneaky' | 'Lotto';
  notes: string;
  whatCouldGoWrong: string;
  missingData: string[];
  parlayAllowed: boolean;
}

export interface CombinedJudgeOutput {
  finalScore: number;
  approvalStatus: 'Approved' | 'Playable but risky' | 'Needs more data' | 'Avoid';
  riskLabel: 'Safe' | 'Balanced' | 'Risky' | 'Sneaky' | 'Lotto';
  judgeNotes: string[];
  whatCouldGoWrong: string[];
  missingData: string[];
  parlayAllowed: boolean;
  individualResults: IndividualJudgeResult[];
}
