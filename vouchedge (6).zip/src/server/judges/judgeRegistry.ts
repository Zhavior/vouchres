import { JudgeConfig } from './judgeTypes';

export const JUDGE_REGISTRY: Record<string, JudgeConfig> = {
  pick_logic: {
    id: 'pick_logic',
    name: 'Pick Logic Auditor',
    description: 'Ensures the selection has strong fundamental sport rationale and isn\'t based on stale stats.',
    weight: 0.9,
    checks: ['recent team performance', 'head to head matchups', 'injury impact status', 'rest disadvantage'],
    outputFields: ['fundamentalScore', 'restFactorChecked', 'injuryReportPassed'],
    category: 'sports_logic'
  },
  risk: {
    id: 'risk',
    name: 'Risk & Leverage Evaluator',
    description: 'Calculates the optimal unit allocation and guards against over-leveraging.',
    weight: 1.0,
    checks: ['implied probability mismatch', 'unit sizing guidelines', 'overall bankroll risk exposure'],
    outputFields: ['recommendedUnits', 'maxAllowedRisk', 'volatilityGrade'],
    category: 'bias_risk'
  },
  bias: {
    id: 'bias',
    name: 'Cognitive Bias Detector',
    description: 'Flags sentiment bias, hot hand fallacies, fan bias, and home team overvaluation.',
    weight: 0.8,
    checks: ['home team favor bias', 'streak chase detection', 'emotional public volume alignment'],
    outputFields: ['biasScore', 'detectedBiases', 'reconciliationAction'],
    category: 'bias_risk'
  },
  trust: {
    id: 'trust',
    name: 'Transparency & Trust Guardian',
    description: 'Ensures verified historical source transparency, auditing previous predictions and odds sources.',
    weight: 0.95,
    checks: ['bookie source validation', 'historical ledger accuracy', 'public performance history'],
    outputFields: ['trustRating', 'ledgerMatchStatus', 'unverifiedClaimWarning'],
    category: 'data_integrity'
  },
  data_quality: {
    id: 'data_quality',
    name: 'Data Feed Quality Grader',
    description: 'Grades the completeness and latency of underlying statistics and real-time feeds.',
    weight: 0.85,
    checks: ['api stream freshness', 'missing sample variables', 'historical statistical consistency'],
    outputFields: ['feedLatencySeconds', 'sampleSizeSufficient', 'dataQualityTier'],
    category: 'data_integrity'
  },
  correlation: {
    id: 'correlation',
    name: 'Parlay Correlation Auditor',
    description: 'Detects negative correlation traps in parlay legs and calculates compounding math.',
    weight: 0.75,
    checks: ['same game event dependency', 'counter-correlated outcomes', 'compounding odds multiplier check'],
    outputFields: ['negativeCorrelationDetected', 'trueOddsCalculation', 'playableParlayRating'],
    category: 'sports_logic'
  },
  lineup: {
    id: 'lineup',
    name: 'Confirmed Lineup Auditor',
    description: 'Validates starting lineups, late scratches, and rotational changes in active team rosters.',
    weight: 0.8,
    checks: ['starting pitchers confirmed', 'late scratches validation', 'depth chart replacement score'],
    outputFields: ['lineupMatchPct', 'keyPlayerMissing', 'lineupCertaintyLevel'],
    category: 'sports_logic'
  },
  weather_park: {
    id: 'weather_park',
    name: 'Weather & Venue Analyst',
    description: 'Evaluates field dimensions, wind patterns, precipitation risk, and park factors.',
    weight: 0.7,
    checks: ['wind speed and vectors', 'stadium elevation impact', 'humidity and rain probability'],
    outputFields: ['fieldFactorAdjustment', 'weatherAlertLevel', 'temperaturePowerShift'],
    category: 'sports_logic'
  },
  market_value: {
    id: 'market_value',
    name: 'Market pricing value auditor',
    description: 'Scans multiple sportsbooks to find line discrepancies and positive expected value (+EV).',
    weight: 0.85,
    checks: ['closing line value projections', 'multi-book spread variance', 'juice/vig percentage assessment'],
    outputFields: ['evPercentage', 'bestOddsSource', 'arbitrageRiskWarning'],
    category: 'sports_logic'
  },
  result_review: {
    id: 'result_review',
    name: 'Historical Outcome Verifier',
    description: 'Audits finished games, grades result slips, and logs performance metrics into the trust ledger.',
    weight: 0.9,
    checks: ['official score matching', 'refund/push grading', 'ledger transaction validation'],
    outputFields: ['gradedOutcome', 'finalResultDiff', 'auditorApprovalHash'],
    category: 'data_integrity'
  },
  
  // USER CUSTOM REQUESTED THEMES/JUDGES: UI Judge, Design Judge Outerlayer, Design Judge Innerlayer
  ui_judge: {
    id: 'ui_judge',
    name: 'UI Judge',
    description: 'Inspects user interfaces, card presentation, text density, and contrast ratios for maximum usability.',
    weight: 0.75,
    checks: ['visual accessibility checks', 'line width density', 'contrast ratio comfort', 'typography hierarchy rules'],
    outputFields: ['contrastPassed', 'textReadabilityScore', 'screenUtilizationFactor'],
    category: 'ui_design'
  },
  design_judge_outer: {
    id: 'design_judge_outer',
    name: 'Design Judge Outerlayer',
    description: 'Analyzes external container boundaries, page margins, responsive layout gutters, and spacing pacing.',
    weight: 0.65,
    checks: ['desktop responsive grids', 'canvas boundary ratios', 'excessive container stretching', 'safe zone padding'],
    outputFields: ['marginComfortFactor', 'gutterSizingCorrect', 'responsiveGridScore'],
    category: 'ui_design'
  },
  design_judge_inner: {
    id: 'design_judge_inner',
    name: 'Design Judge Innerlayer',
    description: 'Audits local card items, shadow depths, element alignment, hover feedback states, and micro-interactivity.',
    weight: 0.65,
    checks: ['hover style presence', 'rounded border continuity', 'badge alignment', 'micro animation durations'],
    outputFields: ['hoverInteractiveRating', 'alignmentCertainty', 'depthTextureScore'],
    category: 'ui_design'
  }
};

export function getJudgeConfig(judgeId: string): JudgeConfig | undefined {
  return JUDGE_REGISTRY[judgeId];
}

export function getAllJudges(): JudgeConfig[] {
  return Object.values(JUDGE_REGISTRY);
}
