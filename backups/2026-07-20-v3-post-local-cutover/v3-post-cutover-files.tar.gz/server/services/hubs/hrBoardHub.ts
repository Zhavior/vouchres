import { isUpstashEnabled, redisGetJson, redisSetJson } from "../../lib/upstashRedis";
import { buildHrBoardResponse } from "../mlb/hr-engine/buildHrBoardResponse";
import { buildValidatedHrBoard } from "../mlb/hrPipeline";
import { buildHrBoard } from "../mlb/dailyHrBoardService";
import { getTodayGamesWeather } from "../mlb/weatherService";
import { getMaterializedHrResearch } from "../mlb/hrResearchSnapshotService";
import { limitConcurrency } from "../../lib/cache";

const LAST_GOOD_WARNING = "Serving last good snapshot — upstream temporarily unavailable";
const LAST_GOOD_TTL_MS = Number(process.env.VALIDATED_HR_BOARD_LAST_GOOD_MS ?? 60 * 60_000);

type HrBoardSnapshot = Awaited<ReturnType<typeof buildHrBoardResponse>>;

type CacheEntry = {
  expiresAt: number;
  board: HrBoardSnapshot;
};

const localHrBoardCache = new Map<string, CacheEntry>();
const localHrBoardBuilds = new Map<string, Promise<HrBoardSnapshot>>();

function cacheKey(date?: string | null, previewLimit = 350): string {
  return `hr-board:${date ?? "today"}:preview:${previewLimit}`;
}

export async function getCachedHrBoardResponse(input: {
  date?: string | null;
  previewLimit?: number;
} = {}): Promise<HrBoardSnapshot> {
  const previewLimit = input.previewLimit ?? 350;
  const key = cacheKey(input.date, previewLimit);
  const ttlSeconds = Number(process.env.HR_BOARD_HUB_TTL_SECONDS ?? 900);

  const cached = localHrBoardCache.get(key);
  if (cached && cached.expiresAt > Date.now()) {
    console.log(`[HR_BOARD_HUB] local hit key=${key}`);
    return cached.board;
  }

  if (cached) {
    localHrBoardCache.delete(key);
  }

  const activeBuild = localHrBoardBuilds.get(key);
  if (activeBuild) {
    console.log(`[HR_BOARD_HUB] awaiting local build key=${key}`);
    return activeBuild;
  }

  const buildPromise = (async () => {
    console.log(`[HR_BOARD_HUB] building key=${key}`);

    const board = await buildHrBoardResponse({
      date: input.date ?? undefined,
      previewLimit,
    });

    localHrBoardCache.set(key, {
      expiresAt: Date.now() + ttlSeconds * 1000,
      board,
    });

    console.log(`[HR_BOARD_HUB] local set key=${key} ttl=${ttlSeconds}s`);
    return board;
  })();

  localHrBoardBuilds.set(key, buildPromise);

  try {
    return await buildPromise;
  } finally {
    localHrBoardBuilds.delete(key);
  }
}

type ValidatedHrBoardSnapshot = Awaited<ReturnType<typeof buildValidatedHrBoard>>;
type DeepHrBoardSnapshot = Awaited<ReturnType<typeof buildHrBoard>>;

type ValidatedCacheEntry = {
  expiresAt: number;
  board: ValidatedHrBoardSnapshot;
};

type DeepCacheEntry = {
  expiresAt: number;
  board: DeepHrBoardSnapshot;
};

const localValidatedHrBoardCache = new Map<string, ValidatedCacheEntry>();
const localValidatedHrBoardBuilds = new Map<string, Promise<ValidatedHrBoardSnapshot>>();
const lastGoodValidatedHrBoards = new Map<string, { board: ValidatedHrBoardSnapshot; storedAt: number }>();

type ValidatedPlayerCandidate = Record<string, unknown>;

type ValidatedPlayerIndexEntry = {
  expiresAt: number;
  generatedAt: string | null;
  candidates: Map<number, ValidatedPlayerCandidate>;
};

const localValidatedPlayerIndex = new Map<string, ValidatedPlayerIndexEntry>();

function validatedBoardGeneratedAt(board: ValidatedHrBoardSnapshot): string | null {
  return typeof (board as any).updatedAt === "string"
    ? (board as any).updatedAt
    : typeof (board as any).generatedAt === "string"
      ? (board as any).generatedAt
      : null;
}

function buildValidatedPlayerIndex(
  key: string,
  board: ValidatedHrBoardSnapshot,
  expiresAt: number,
): void {
  const candidatePools = [
    Array.isArray(board.candidates) ? board.candidates : [],
    Array.isArray(board.projectedCandidates) ? board.projectedCandidates : [],
    Array.isArray((board as any).allProjectedCandidates)
      ? (board as any).allProjectedCandidates
      : [],
  ];

  const candidates = new Map<number, ValidatedPlayerCandidate>();

  for (const row of candidatePools.flat()) {
    if (!row || typeof row !== "object") continue;

    const playerId = Number((row as Record<string, unknown>).playerId);
    if (!Number.isInteger(playerId) || playerId <= 0) continue;

    // Preserve first occurrence: confirmed candidates are indexed before previews.
    if (!candidates.has(playerId)) {
      candidates.set(playerId, row as ValidatedPlayerCandidate);
    }
  }

  const generatedAt = validatedBoardGeneratedAt(board);

  localValidatedPlayerIndex.set(key, {
    expiresAt,
    generatedAt,
    candidates,
  });

  console.log(
    `[HR_BOARD_HUB] indexed ${candidates.size} validated/projected players key=${key}`,
  );
}
const LAST_GOOD_REDIS_PREFIX = "validated-hr-board:last-good";
const VALIDATED_HOT_REDIS_PREFIX = "validated-hr-board:hot";

type LastGoodEntry = { board: ValidatedHrBoardSnapshot; storedAt: number };

export type ValidatedHrBoardResult = ValidatedHrBoardSnapshot & {
  servedFromLastGood?: boolean;
  lastGoodWarnings?: string[];
};

async function persistLastGoodToRedis(key: string, entry: LastGoodEntry): Promise<void> {
  if (!isUpstashEnabled()) return;

  const redisKey = `${LAST_GOOD_REDIS_PREFIX}:${key}`;
  const ttlSeconds = Math.max(1, Math.floor(LAST_GOOD_TTL_MS / 1000));
  try {
    await redisSetJson(redisKey, entry, ttlSeconds);
  } catch (error) {
    console.warn(
      `[HR_BOARD_HUB] redis last-good write failed key=${key}`,
      (error as Error)?.message,
    );
  }
}

async function loadLastGoodFromRedis(key: string): Promise<LastGoodEntry | null> {
  if (!isUpstashEnabled()) return null;

  const redisKey = `${LAST_GOOD_REDIS_PREFIX}:${key}`;
  try {
    const remote = await redisGetJson<LastGoodEntry>(redisKey);
    if (!remote?.board || typeof remote.storedAt !== "number") return null;

    const ageMs = Date.now() - remote.storedAt;
    if (ageMs > LAST_GOOD_TTL_MS) return null;

    lastGoodValidatedHrBoards.set(key, remote);
    console.log(`[HR_BOARD_HUB] redis last-good hit key=${key} ageMs=${ageMs}`);
    return remote;
  } catch (error) {
    console.warn(
      `[HR_BOARD_HUB] redis last-good read failed key=${key}`,
      (error as Error)?.message,
    );
    return null;
  }
}

function rememberLastGoodValidatedBoard(key: string, board: ValidatedHrBoardSnapshot): void {
  const entry: LastGoodEntry = { board, storedAt: Date.now() };
  lastGoodValidatedHrBoards.set(key, entry);
  void persistLastGoodToRedis(key, entry);
}

async function serveLastGoodValidatedBoard(key: string, cause: unknown): Promise<ValidatedHrBoardResult | null> {
  let lastGood = lastGoodValidatedHrBoards.get(key);
  if (!lastGood) {
    lastGood = (await loadLastGoodFromRedis(key)) ?? undefined;
  }
  if (!lastGood) return null;

  const ageMs = Date.now() - lastGood.storedAt;
  if (ageMs > LAST_GOOD_TTL_MS) return null;

  console.warn(
    `[HR_BOARD_HUB] serving last-good validated board key=${key} ageMs=${ageMs}:`,
    cause instanceof Error ? cause.message : String(cause),
  );

  const staleDataWarnings = Array.from(
    new Set([...(lastGood.board.debug?.staleDataWarnings ?? []), LAST_GOOD_WARNING]),
  );

  return {
    ...lastGood.board,
    servedFromLastGood: true,
    lastGoodWarnings: [LAST_GOOD_WARNING],
    debug: {
      ...lastGood.board.debug,
      staleDataWarnings,
      lastRefresh: lastGood.board.debug?.lastRefresh ?? new Date(lastGood.storedAt).toISOString(),
    },
  };
}

/** Test-only reset for hub caches and last-good snapshots. */
export function resetValidatedHrBoardHubForTests(): void {
  localValidatedHrBoardCache.clear();
  localValidatedHrBoardBuilds.clear();
  lastGoodValidatedHrBoards.clear();
  localValidatedPlayerIndex.clear();
}

/** Test-only: force a rebuild on next fetch while keeping last-good snapshots. */
export function expireValidatedHrBoardHubCacheForTests(): void {
  localValidatedHrBoardCache.clear();
}

const localDeepHrBoardCache = new Map<string, DeepCacheEntry>();
const localDeepHrBoardBuilds = new Map<string, Promise<DeepHrBoardSnapshot>>();

function currentMlbDate(): string {
  // MLB slate dates should follow Eastern Time rather than server UTC.
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/New_York",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

function validatedKey(date?: string | null): string {
  const normalizedDate = date?.trim() || null;
  const canonicalDate =
    !normalizedDate || normalizedDate === currentMlbDate()
      ? "today"
      : normalizedDate;

  return `validated-hr-board:${canonicalDate}`;
}

function deepKey(date?: string | null): string {
  return `deep-hr-board:${date ?? "today"}`;
}

async function persistValidatedHotToRedis(key: string, entry: ValidatedCacheEntry): Promise<void> {
  if (!isUpstashEnabled()) return;

  const redisKey = `${VALIDATED_HOT_REDIS_PREFIX}:${key}`;
  const ttlSeconds = Math.max(1, Math.floor((entry.expiresAt - Date.now()) / 1000));
  try {
    await redisSetJson(redisKey, entry, ttlSeconds);
  } catch (error) {
    console.warn(
      `[HR_BOARD_HUB] validated redis hot write failed key=${key}`,
      (error as Error)?.message,
    );
  }
}

async function loadValidatedHotFromRedis(key: string): Promise<ValidatedCacheEntry | null> {
  if (!isUpstashEnabled()) return null;

  const redisKey = `${VALIDATED_HOT_REDIS_PREFIX}:${key}`;
  try {
    const remote = await redisGetJson<ValidatedCacheEntry>(redisKey);
    if (!remote?.board || typeof remote.expiresAt !== "number") return null;
    if (remote.expiresAt <= Date.now()) return null;

    localValidatedHrBoardCache.set(key, remote);
    buildValidatedPlayerIndex(key, remote.board, remote.expiresAt);
    console.log(`[HR_BOARD_HUB] validated redis hot hit key=${key}`);
    return remote;
  } catch (error) {
    console.warn(
      `[HR_BOARD_HUB] validated redis hot read failed key=${key}`,
      (error as Error)?.message,
    );
    return null;
  }
}

type ProfilePrewarmCandidate = {
  playerId: number;
  candidate: Record<string, unknown>;
};

function positiveNumber(value: unknown): number | undefined {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : undefined;
}

function profilePrewarmCandidates(
  board: ValidatedHrBoardSnapshot,
): ProfilePrewarmCandidate[] {
  const configuredLimit = Number(process.env.HR_PROFILE_PREWARM_LIMIT ?? 6);
  const limit = Math.max(0, Math.min(12, configuredLimit));

  if (limit === 0) return [];

  const candidatePools = [
    Array.isArray(board.candidates) ? board.candidates : [],
    Array.isArray(board.projectedCandidates) ? board.projectedCandidates : [],
  ];

  const seen = new Set<number>();
  const selected: ProfilePrewarmCandidate[] = [];

  for (const row of candidatePools.flat()) {
    if (!row || typeof row !== "object") continue;

    const candidate = row as unknown as Record<string, unknown>;
    const playerId = positiveNumber(candidate.playerId);

    if (!playerId || seen.has(playerId)) continue;

    seen.add(playerId);

    selected.push({
      playerId,
      candidate,
    });

    if (selected.length >= limit) break;
  }

  return selected;
}

function scheduleProfileResearchPrewarm(
  key: string,
  board: ValidatedHrBoardSnapshot,
): void {
  const candidates = profilePrewarmCandidates(board);
  if (!candidates.length) return;

  const configuredConcurrency = Number(
    process.env.HR_PROFILE_PREWARM_CONCURRENCY ?? 2,
  );
  const concurrency = Math.max(1, Math.min(4, configuredConcurrency));
  const startedAt = Date.now();

  void limitConcurrency(
    candidates,
    concurrency,
    async (candidate) => {
      try {
        await getMaterializedHrResearch({
          candidate: candidate.candidate,
          generatedAt: validatedBoardGeneratedAt(board),
        });

        return true;
      } catch (error) {
        console.warn(
          `[HR_BOARD_HUB] profile prewarm failed key=${key} playerId=${candidate.playerId}:`,
          error instanceof Error ? error.message : String(error),
        );
        return false;
      }
    },
  )
    .then((results) => {
      const warmed = results.filter(Boolean).length;

      console.log(
        `[HR_BOARD_HUB] profile prewarm complete key=${key} warmed=${warmed}/${candidates.length} durationMs=${Date.now() - startedAt}`,
      );
    })
    .catch((error) => {
      console.warn(
        `[HR_BOARD_HUB] profile prewarm batch failed key=${key}:`,
        error instanceof Error ? error.message : String(error),
      );
    });
}

async function buildFreshValidatedBoard(
  key: string,
  date: string | null | undefined,
  ttlSeconds: number,
): Promise<ValidatedHrBoardResult> {
  console.log(`[HR_BOARD_HUB] validated building key=${key}`);

  const weatherPrewarm = getTodayGamesWeather(date ?? undefined)
    .then((rows) => {
      console.log(
        `[HR_BOARD_HUB] weather prewarm complete key=${key} games=${rows.length}`,
      );
      return rows;
    })
    .catch((error) => {
      // Weather is supporting research context, not a board truth prerequisite.
      // Keep the validated board available when the forecast provider is degraded.
      console.warn(
        `[HR_BOARD_HUB] weather prewarm failed key=${key}:`,
        error instanceof Error ? error.message : String(error),
      );
      return [];
    });

  const [board] = await Promise.all([
    buildValidatedHrBoard(date ?? undefined),
    weatherPrewarm,
  ]);

  rememberLastGoodValidatedBoard(key, board);

  const entry: ValidatedCacheEntry = {
    expiresAt: Date.now() + ttlSeconds * 1000,
    board,
  };
  localValidatedHrBoardCache.set(key, entry);
  buildValidatedPlayerIndex(key, board, entry.expiresAt);
  void persistValidatedHotToRedis(key, entry);

  console.log(`[HR_BOARD_HUB] validated local set key=${key} ttl=${ttlSeconds}s`);

  // Background-only warmup. Never delay board availability.
  scheduleProfileResearchPrewarm(key, board);

  return board;
}

function scheduleValidatedRefresh(
  key: string,
  date: string | null | undefined,
  ttlSeconds: number,
): void {
  if (localValidatedHrBoardBuilds.has(key)) return;

  const buildPromise = (async (): Promise<ValidatedHrBoardResult> => {
    try {
      return await buildFreshValidatedBoard(key, date, ttlSeconds);
    } catch (err) {
      const fallback = await serveLastGoodValidatedBoard(key, err);
      if (fallback) return fallback;
      throw err;
    }
  })();

  localValidatedHrBoardBuilds.set(key, buildPromise);
  void buildPromise.finally(() => {
    localValidatedHrBoardBuilds.delete(key);
  });
}

export async function getCachedValidatedHrCandidate(
  playerId: number,
  date?: string | null,
): Promise<{
  candidate: ValidatedPlayerCandidate | null;
  generatedAt: string | null;
  source: "player_index" | "board_fallback";
}> {
  const key = validatedKey(date);
  const indexed = localValidatedPlayerIndex.get(key);

  if (indexed && indexed.expiresAt > Date.now()) {
    const candidate = indexed.candidates.get(playerId) ?? null;

    if (candidate) {
      console.log(
        `[HR_BOARD_HUB] validated player index hit key=${key} playerId=${playerId}`,
      );

      return {
        candidate,
        generatedAt: indexed.generatedAt,
        source: "player_index",
      };
    }
  }

  const board = await getCachedValidatedHrBoard(date);
  const cached = localValidatedHrBoardCache.get(key);

  buildValidatedPlayerIndex(
    key,
    board,
    cached?.expiresAt ?? Date.now() + 60_000,
  );

  const refreshed = localValidatedPlayerIndex.get(key);

  return {
    candidate: refreshed?.candidates.get(playerId) ?? null,
    generatedAt: refreshed?.generatedAt ?? null,
    source: "board_fallback",
  };
}

export async function getCachedValidatedHrBoard(date?: string | null): Promise<ValidatedHrBoardResult> {
  const key = validatedKey(date);
  const ttlSeconds = Number(process.env.VALIDATED_HR_BOARD_HUB_TTL_SECONDS ?? 900);

  const cached = localValidatedHrBoardCache.get(key);
  if (cached) {
    if (cached.expiresAt > Date.now()) {
      console.log(`[HR_BOARD_HUB] validated local hit key=${key}`);
      return cached.board;
    }

    console.log(`[HR_BOARD_HUB] validated stale hit key=${key} — refreshing in background`);
    scheduleValidatedRefresh(key, date, ttlSeconds);
    return cached.board;
  }

  const activeBuild = localValidatedHrBoardBuilds.get(key);
  if (activeBuild) {
    console.log(`[HR_BOARD_HUB] validated awaiting local build key=${key}`);
    return activeBuild;
  }

  const redisHot = await loadValidatedHotFromRedis(key);
  if (redisHot) {
    return redisHot.board;
  }

  const buildPromise = (async (): Promise<ValidatedHrBoardResult> => {
    try {
      return await buildFreshValidatedBoard(key, date, ttlSeconds);
    } catch (err) {
      const fallback = await serveLastGoodValidatedBoard(key, err);
      if (fallback) return fallback;
      throw err;
    }
  })();

  localValidatedHrBoardBuilds.set(key, buildPromise);

  try {
    return await buildPromise;
  } finally {
    localValidatedHrBoardBuilds.delete(key);
  }
}

export async function getCachedDeepHrBoard(date?: string | null): Promise<DeepHrBoardSnapshot> {
  const key = deepKey(date);
  const ttlSeconds = Number(process.env.DEEP_HR_BOARD_HUB_TTL_SECONDS ?? 1200);

  const cached = localDeepHrBoardCache.get(key);
  if (cached && cached.expiresAt > Date.now()) {
    console.log(`[HR_BOARD_HUB] deep local hit key=${key}`);
    return cached.board;
  }

  if (cached) {
    localDeepHrBoardCache.delete(key);
  }

  const activeBuild = localDeepHrBoardBuilds.get(key);
  if (activeBuild) {
    console.log(`[HR_BOARD_HUB] deep awaiting local build key=${key}`);
    return activeBuild;
  }

  const buildPromise = (async () => {
    console.log(`[HR_BOARD_HUB] deep building key=${key}`);
    const board = await buildHrBoard(date ?? undefined);

    localDeepHrBoardCache.set(key, {
      expiresAt: Date.now() + ttlSeconds * 1000,
      board,
    });

    console.log(`[HR_BOARD_HUB] deep local set key=${key} ttl=${ttlSeconds}s`);
    return board;
  })();

  localDeepHrBoardBuilds.set(key, buildPromise);

  try {
    return await buildPromise;
  } finally {
    localDeepHrBoardBuilds.delete(key);
  }
}
