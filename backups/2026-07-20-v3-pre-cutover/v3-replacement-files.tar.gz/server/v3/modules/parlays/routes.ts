import { Router } from "express";
import { parlayUserRoutes } from "../../../routes/parlay/parlayUserRoutes";

/**
 * V3 parlay ownership routes reuse the proven authenticated user parlay router
 * during migration. Staff grading flows live under the dedicated V3 grading
 * module; this router owns user-facing parlay creation and lifecycle actions.
 */
export const v3ParlayRoutes = Router();

v3ParlayRoutes.use(parlayUserRoutes);
