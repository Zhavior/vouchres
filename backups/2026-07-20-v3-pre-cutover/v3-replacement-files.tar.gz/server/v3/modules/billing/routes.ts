import { billingRoutes } from "../../../routes/billingRoutes";

/**
 * V3 billing routes currently reuse the proven billing router so Stripe,
 * subscription sync, and entitlement behavior stay identical during migration.
 */
export const v3BillingRoutes = billingRoutes;
