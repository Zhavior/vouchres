import type { Response } from "express";
import { Router } from "express";
import { AppError } from "../../../errors/AppError";
import { asyncHandler } from "../../../lib/asyncHandler";
import { apiOkFlat } from "../../../lib/apiResponse";
import type { RequestWithContext } from "../../../middleware/requestContext";
import { getVerifiedRecord } from "../../../services/trust/verifiedRecordService";
import { getCapperTrust, getUserTrust } from "../../../services/trust/trustScoreService";

export const v3TrustRoutes = Router();

function requirePathId(value: unknown, field: string): string {
  const id = typeof value === "string" ? value.trim() : "";
  if (!id) {
    throw new AppError({
      status: 400,
      code: "validation_error",
      message: `${field} is required.`,
      details: [{ path: field, message: "Required." }],
    });
  }
  return id;
}

v3TrustRoutes.get(
  "/user/:userId",
  asyncHandler(async (req: RequestWithContext, res: Response) => {
    const userId = requirePathId(req.params.userId, "userId");
    return res.json(apiOkFlat(req, {
      version: "v3",
      trust: await getUserTrust(userId),
    }));
  }),
);

v3TrustRoutes.get(
  "/capper/:capperId",
  asyncHandler(async (req: RequestWithContext, res: Response) => {
    const capperId = requirePathId(req.params.capperId, "capperId");
    const [trust, verifiedRecord] = await Promise.all([
      getCapperTrust(capperId),
      getVerifiedRecord(capperId),
    ]);

    return res.json(apiOkFlat(req, {
      version: "v3",
      trust,
      verifiedRecord,
    }));
  }),
);
